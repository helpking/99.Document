//
//  RuntimeDownloadManager.h
//  chaos
//  都度DL専用のリソース管理マネージャー
//  Created by 何利強 on 2016/01/07.
//
//

#ifndef __chaos__RuntimeDownloadManager__
#define __chaos__RuntimeDownloadManager__

#include <queue>

#include <core/library/lib_json_document.h>
#include "application/joker_application_types.h"
#include "cocos-ext.h"
#include "cocos2d.h"

#include "ResourcesManager/downloader.h"
#include "ResourcesManager/unziper.h"
#include "parameter/download_parameter.h"

using namespace cocos2d;

namespace Chaos {
namespace ResourcesManager {

static const S32 kMaxCurlDlThreads = 3;

/**
 * @brief 都度DL専用のマネージャーデリゲート
 */
class RuntimeDownloadManagerDelegate {
public:
    /**
     * @brief ダウンロードターゲットが未存在の場合、行うメソッド
     */
    virtual void downloadWhenNoTargetResource() = 0;
    /**
     * \brief ダウンロードがキャンセルされた場合に呼び出されます
     */
    virtual void DownloadCancel(){};
};

/**
 * @brief 都度DL専用のマネージャー
 */
class RuntimeDownloadManager : public cocos2d::CCObject {
public:
    /**
     * @brief リソースDLタイプ
     */
    typedef enum TDownloadOption {
        /** @brief -1:無効 */
        kTDownloadOptionInvalid = -1,
        /** @brief 0:都度DL(ファイル名で) */
        kTDownloadOptionNormal,
        /** @brief 1:一括ダウンロード */
        kTDownloadOptionAll,
        kTDownloadOptionMax
    } TDownloadOption;

    RuntimeDownloadManager();
    virtual ~RuntimeDownloadManager();

    /**
     * @brief シングルトンインスタンスを返します。
     */
    static RuntimeDownloadManager* SharedManager();

    /**
     * @brief リソースのテクスチャを取得する
     * @param[in] iTextureName リソースのテクスチャ名
     * @param[in] iIsDummyFlg ダミーフラグ
     */
    cocos2d::CCSprite* getResSprite(const char* iTextureName,
                                    Bool& iIsDummyFlg);

    /**
     * @brief リソースのテクスチャを取得する
     * @param[in] iTextureName リソースのテクスチャ名
     * @param[in] iTargetSprite ターゲットスプライト
     * @param[in] iAddCheckAPIFlg
     * チェック用のAPI(resource/get)が発生するかどうかのフラグ
     * @return ダミーフラグ
     */
    Bool getResTexture(const char* iTextureName, CCSprite* iTargetSprite,
                       Bool iAddCheckAPIFlg = true);

    /**
     * @brief 都度DLをするため、チェック用の情報を追加する
     * @param[in] iCheckFileName チェック用のファイル名
     */
    void pushResourceDownloadCheckInfo(const char* iCheckFileName);

    /**
     * @brief 都度DLで、ダウンロード用のターゲット情報を追加する
     * @param[in] iResourceType リソースタイプ
     * @param[in] iDetailId 詳細ID
     */
    void pushDownloadTargetInfoByDetailId(
        const JOKER::TResourceType iResourceType, const S64 iDetailId);

    /**
     * @brief 都度DLが発生するAPIで、ダウンロード用の情報を解析する
     * @param[in] iJsonData JSONデーター
     */
    const Bool parseDownloadsInfoByApiResponse(
        const adk::LIB_JsonValue* iJsonData);

    /**
     * @brief 都度DLが発生するAPIで、ダウンロード用の情報を解析する
     * @param[in] iJsonData JSONデーター
     */
    const Bool parseDownloadsInfoByApiResponse(CCDictionary* iJsonData);

    /**
     * @brief 都度DLで、ローディングパーツを消す
     */
    virtual void removeLoadingParts();

    /**
     * @brief 全スレッドが止まってるかどうかのチェックを行う
     * @return 全スレッド止まるフラグ
     */
    const Bool isAllThreadStoped();

    /**
     * @brief
     * ローカルDBへ、すでにダウンロードされたリソースカード情報をリセットする(デバッグ機能のみ、使う)
     * @param[in] iCardId 詳細ID
     */
    const void resetRuntimeDownloadCardResourceInfoToLocalDB(
        const S32 iCardId = -1);

    /**
     * @brief
     * 次回のダウンロードを起動するため、ダウンロードインデックス情報をリセットする
     */
    inline const void resetDownloadIndex() {
        this->cur_download_index_ = this->next_download_index_;
        ++next_download_index_;
    };

    /**
     * @brief ダウンロードが停止しているかどうかの判定
     *        (注意：ダウンロードを走ってから、停止するかどうかのを判定しますが、途中でキャンセルされても、ダウンロードしたにする)
     * @return ダウンロードがすでに走ったかどうかのフラグ
     */
    inline const Bool isDownloadStoped() {
        return (this->isDownloadStarted_ && (!this->isDownloadExecuting()));
    };

    /**
     * @brief
     * DLマネージャーから、ダウンロード用のオプション：ダウンロードタイプを取得する
     * @return ダウンロード用のリソースタイプ
     */
    inline const TDownloadOption getDownloadOption() const {
        return this->download_Option_;
    }

    /**
     * @brief API:resource/getのURLを取得する
     * @return resource/getのURL
     */
    inline const char* getApiResGetUrl() const { return this->apiResGetUrl_; };

    /**
     * @brief ダウンロード中POP表示中フラグを「off」にする
     * @param[in] iDownloadIndexAutoResetFlg
     * ダウンロードインデックス自動リセットフラグ
     */
    inline const void setDownloadingPopDisplayingOff(
        const Bool iDownloadIndexAutoResetFlg = false) {
        this->isDownloadingPopDisplaying_ = false;
        if (iDownloadIndexAutoResetFlg) {
            this->resetDownloadIndex();
        }
    };

private:
    /** @brief 「API:resource/get」の送信中フラグ */
    Bool isResGetApiSending_;
    /** @brief ダウンロードの開始フラグ */
    Bool isDownloadStarted_;

    /** @brief ダウンロード中POP表示中フラグ */
    Bool isDownloadingPopDisplaying_;

    /** @brief カレントのダウンロードインデックス */
    S32 cur_download_index_;

    /** @brief 次用のダウンロードインデックス */
    S32 next_download_index_;

    // ターゲットシーン
    CCNode* targetScene_;

    RuntimeDownloadManagerDelegate* downloadDelegate_;

    // API:resource/getのURL
    Char apiResGetUrl_[DL_RES_COMMON_BUFFER_MAX_LEN];

    /**
     * @brief 都度DL用マネージャー情報をクリアする
     */
    void clearManagerInfo();

    /**
     * @brief スレッドズをチェックして、完了する前
     * @param[in] iDeltaTime
     */
    void waitForThreadsCompleted(F32 iDeltaTime);

    /**
     * @brief ダウンロード用のターゲットズ情報をクリーンアップする
     */
    void CleanUpDownloadTargetsInfo();

    /**
     * @brief リソース情報を取得するため、問い合わせるリクエストを投げる
     * @param[in] iDlResManager 都度DL専用のリソースマネージャー
     */
    static void sentResourceGetRequest(void* iDlResManager);

    /**
     * @brief
     * リソース情報を取得する問い合わせるリクエストが返してくるコールバック
     * @param[in] iIsSuccessFlg 通信成功フラグ
     * @param[in] iResInfoData リソース情報データ
     */
    Bool CompeletedGetResInfoByFileName(Bool iIsSuccessFlg,
                                        const adk::LIB_JsonValue* iResInfoData);

    /**
     * @brief API:resource/getのURLをセットする
     * @param[in] iUrl URL
     */
    inline void setApiResGetUrl(const char* iUrl) {
        strncpy(this->apiResGetUrl_, iUrl, sizeof(this->apiResGetUrl_));
        this->apiResGetUrl_[sizeof(this->apiResGetUrl_) - 1] = 0;
    };

    /**
     * @brief 都度DL用のURL情報を初期化する
     */
    void initDlResUrlInfo();

#pragma mark -
#pragma mark v3.12.0から、改修

public:
    /**
     * @brief 都度DLスレッドを開始する
     * @param[in] iTargetScene ターゲットシーン
     * @param[in] iDownloadDegelage ダウンロードデリゲート
     */
    void StartUpDownloadThread(
        CCNode* iTargetScene = NULL,
        RuntimeDownloadManagerDelegate* iDownloadDegelage = NULL);

    /**
     * @brief
     * 都度DLスレッドを開始する(一括DLオプションより、残るリソースをダウンロードする)
     * @param[in] iTargetScene ターゲットシーン
     * @param[in] iDownloadDegelage ダウンロードデリゲート
     * @return ダウンロード用のリソース数
     */
    void StartUpDownloadForAllThread(
        CCNode* iTargetScene = NULL,
        RuntimeDownloadManagerDelegate* iDownloadDegelage = NULL);

    /**
     * @brief
     * ローカルDBへ、ダウンロードリソース一覧情報を退避するスレッドを起動する
     */
    void StartUpSaveToLocalDBThread();

    /**
     * @brief 都度DLで、ダウンロード中を示すため、ローディングパーツを追加する
     * @param[in] iTargetScene ターゲットシーン
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iDownloadIndexAutoResetFlg
     * ダウンロードインデックス自動リセットフラグ
     * @return true : 追加されました; false : 追加されなかった;
     */
    virtual Bool addLoadingParts(CCNode* iTargetScene, const S32 iDownloadIndex,
                                 const Bool iDownloadIndexAutoResetFlg = false);

    /**
     * @brief リソースファイルの存在チェック
     * @param[in] iResFileName リソースファイル名
     */
    bool isResourceFileExist(const char* iResFileName);

    /**
     * @brief 都度DLの進捗率を取得する
     * @return 都度DLの進捗率
     */
    const F32 GetDownloadProgressRate() const;

    /**
     * @brief 都度DLをキャンセルする
     */
    const void Cancel();

    /**
     * @brief 都度DLをリトライする
     */
    const void Retry();

    /**
     * @brief ダウンローダーには、通信失敗があるかどうかの判定
     * @return 通信失敗フラグ
     */
    const Bool isDownloaderFailed();

    /**
     * @brief 都度DLには、リトライできるかどうかのチェック
     */
    const Bool isDownloadRetryAble() const;

    /**
     * @brief 前回のリソース更新日付を設定する
     * @param[in] iLastResourceUpdateDate 前回のリソース更新日付
     */
    const void SetLastResourceDate(const S64 iLastResourceUpdateDate);

    /**
     * @brief 前回のリソース情報を設定する
     * @param[in] iLastResourceId 前回のリソースID
     * @param[in] iLastResourceUpdateDate 前回のリソース更新日付
     */
    const void SetLastResourceInfo(const S32 iLastResourceId,
                                   const S64 iLastResourceUpdateDate);

    /**
     * @brief 前回のリソース情報を保存する
     */
    const void SaveLastResourceInfo();

    /**
     * @brief ダウンロードが必要かどうかのチェックを行う
     * @return ダウンロードの必要フラグ
     */
    const Bool isDownloadNecessary() const;

    /**
     * @brief
     * 指定されたリソースのみ、ダウンロードが完了されたかどうかのチェックを行う
     * @param[in] iCheckType チェックタイプ
     * @param[in] iCheckDetailId チェック用のID
     * @param[in] iIsDownloadAutoAdd ダウンロード対象に自動追加フラグ
     *           （trueの場合、自動で、ダウンロードターゲットズリストへ追加する）
     * @return ダウンロードの完了フラグ
     */
    const Bool isDownloadedCompletedByDetailId(
        const JOKER::TResourceType iCheckType, const S32 iCheckDetailId,
        const Bool iIsDownloadAutoAdd = true);

    /**
     * @brief
     * 指定されたリソースのみ、ダウンロードが完了されたかどうかのチェックを行う
     * @param[in] iCheckType チェックタイプ
     * @param[in] iCheckDetailIds チェック用のID詳細一覧
     * @param[in] iIsDownloadAutoAdd ダウンロード対象に自動追加フラグ
     *           （trueの場合、自動で、ダウンロードターゲットズリストへ追加する）
     * @return ダウンロードの完了フラグ
     */
    const Bool isDownloadAllCompletedByDetailIds(
        const JOKER::TResourceType iCheckType,
        const std::vector<S32>* iCheckDetailIds,
        const Bool iIsDownloadAutoAdd = true);

    /**
     * @brief
     * 指定されたリソースのみ、ダウンロードが完了されたかどうかのチェックを行う
     * @return ダウンロードの完了フラグ
     */
    const Bool isDownloadedCompleted();

    /**
     * @brief カードのリソースダウンロードが完了されたかどうかのチェックを行う
     *        注意事項：ダウンロードインデックスをリセットしない
     * @return ダウンロードの完了フラグ
     */
    const Bool isCardDownloadedCompletedByID(const S32 iCardId);

    /**
     * @brief ダウンロードパラメーターへリソース情報を退避する
     * @param[in] iResourceInfo リソース情報
     */
    inline const void addResourceInfoToParameter(
        const JOKER::TResourceInfo* iResourceInfo) {
        if (!download_parameter_) {
            return;
        }
        this->download_parameter_->addResourceInfo(iResourceInfo);
    };

    /**
     * @brief ダウンロードパラメーターへリソース情報を退避する
     * @param[in] iResourceInfo リソース情報
     */
    inline const void saveResourceInfoToParameter(
        const JOKER::TResourceInfo* iResourceInfo) {
        if (!download_parameter_) {
            return;
        }
        this->download_parameter_->saveResourceInfoToLocalDB(iResourceInfo);
    };

    /**
     * @brief 抗争で、リソースをチェックするかどうかのチェックフラグを取得する
     *        ✳︎
     * 抗争バトルで、上記API「guildBattle/prepare/load」を
     *          呼ぶことは複数があるため（例えば：５秒更新）
     *          通信量か、サーバー側へ負担をかからないため初回だけで、
     *          「true」にして、リクエストを投げると、自動で「false」に落とす
     * @return 抗争のリソースチェックフラグ
     */
    inline const Bool isGuildbattleResourceDownloadCheck() const {
        return this->isGvrResourceDownloadCheck_;
    };

    /**
     * @brief 抗争のリソースチェックフラグをリセットする
     *        ✳︎
     * 抗争バトルで、上記API「guildBattle/prepare/load」を
     *          呼ぶことは複数があるため（例えば：５秒更新）
     *          通信量か、サーバー側へ負担をかからないため初回だけで、
     *          「true」にして、リクエストを投げると、自動で「false」に落とす
     * @return 抗争のリソースチェックフラグ
     */
    inline const void setGuildbattleResourceDownloadCheck(const Bool iCheck) {
        this->isGvrResourceDownloadCheck_ = iCheck;
    };

    /**
     * @brief ダウンロードカウント情報を取得する
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @return ダウンロードカウント情報
     */
    inline const JOKER::TDownloadedCountInfo getDownloadedCountInfo(
        const S32 iDownloadIndex = -1) const {
        if (-1 == iDownloadIndex) {
            return this->download_parameter_->getDownloadedCountInfo(
                this->cur_download_index_);
        } else {
            return this->download_parameter_->getDownloadedCountInfo(
                iDownloadIndex);
        }
    };

    /**
     * \brief ダウンロードが開始されたかを返します
     * \return ダウンロード開始フラグ
     */
    const Bool IsDownloadStarted() const { return isDownloadStarted_; }
    /**
     * \brief ダウンロード済みかを返します
     * \return ダウンロード済みか
     */
    const Bool IsAllDownloadCompleted() const {
        return download_parameter_->hadAllResourcesInfoUnzipedToLocalDB();
    }
    
    /**
     * @brief DLResourcesInfoテーブルへの事前登録を中断する
     */
    ADK_INLINE const void interruptAllResourcesSaveThreadToLocalDB();
    /**
     * @brief DLResourcesInfoテーブルへの事前登録のスレッドが停止するかどうかの判定
     */
    ADK_INLINE const Bool isAllResourcesSaveThreadStoped();

private:
    /** ダウンロード用のパラメーター */
    JOKER::DownloadParameter* download_parameter_;

    /** ダウンロードオプション */
    TDownloadOption download_Option_;

    /** @brief ダウンローダーズ */
    Downloader* downloaders_[kMaxCurlDlThreads];
    /** @brief ダウンローダーズカウンター */
    S32 downloaders_count_;
    /** @brief 解凍者 */
    Unziper* unziper_;

    /** @brief 抗争でリソースダウンロードチェックフラグ */
    Bool isGvrResourceDownloadCheck_;
    /** @brief ダウンロードリトライフラグ */
    Bool isDownloadRetry_;

    /**
     * @brief
     * ダウンロード用のリソース一覧情報をローカルDBへの退避することを開始する
     * @param[in] iDlResManager 都度DL専用のリソースマネージャー
     */
    static void startSaveDlResInfoToLocalDB(void* iDlResManager);

    /**
     * @brief リソースファイル(Zip)のダウンロードを開始する
     */
    void BeginDownload();

    /**
     * @brief 「Api:/api/resource/get」のレスポンスデータ解析関数
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iJsonData JSONデータ
     * @return true : 設定成功; false : 設定失敗、または、データなしの場合;
     */
    const Bool parseResourceGetResponseData(
        const S32 iDownloadIndex, const adk::LIB_JsonValue* iJsonData) const;

    /**
     * @brief ダウンロードが実行中であるどうかの判定
     * @return ダウンロードの実行中フラグ
     */
    const Bool isDownloadExecuting() const;

    /**
     * @brief ダウンロードが実行できるかどうかの判定
     * @return ダウンロードの実行できるフラグ
     */
    const Bool isDownloadExecutable() const;

    /**
     * @brief チェック詳細情報の存在チェックを行う
     * @return チェック詳細情報の存在フラグ
     */
    const Bool isCheckDetailInfoExist() const;

    /**
     * @brief チェック詳細情報(ファイルパスで)の存在チェックを行う
     * @return チェック詳細情報(ファイルパスで)の存在フラグ
     */
    const Bool isCheckDetailInfoExistByFilePath() const;

    /**
     * @brief ダウンロード用のターゲットシーンを取得する
     * @return ダウンロード用のターゲットシーン
     */
    CCScene* getDownloadTargetScene();
};
ADK_INLINE const void RuntimeDownloadManager::interruptAllResourcesSaveThreadToLocalDB(){
    if (!this->download_parameter_) {
        return;
    }
    this->download_parameter_->interruptAllResourcesSaveThreadToLocalDB();
};
ADK_INLINE const Bool RuntimeDownloadManager::isAllResourcesSaveThreadStoped(){
    if (!this->download_parameter_) {
        return true;
    }
    return this->download_parameter_->isAllResourcesSaveThreadStoped();
};
}
}

#endif /* defined(__chaos__RuntimeDownloadManager__) */
