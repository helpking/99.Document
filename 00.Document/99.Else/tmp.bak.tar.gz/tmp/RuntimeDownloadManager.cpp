//
//  RuntimeDownloadManager.cpp
//  chaos
//  都度DL専用のリソース管理マネージャー
//  Created by 何利強 on 2016/01/07.
//
//
#include "ResourcesManager/RuntimeDownloadManager.h"

#include "CCDirector.h"
#include "Common.h"
#include "MasterDBInfo.h"
#include "Util.h"
#include "network/ApiInformation.h"
#include "parameter_types.h"

#include <curl/curl.h>
#include "ResourcesManager.h"
#include "SQLiteC++.h"

#include "api_resource_get.h"

#include <core/library/lib_thread.h>

#include "CCBPartsDlResLoading.h"

#include "application/joker_application.h"
#include "parameter/parameter_manager.h"

namespace Chaos {
namespace ResourcesManager {

#define DL_PARTS_LOADING_ZORDER 999999
#define DL_PARTS_LOADING_TAG 999999

static RuntimeDownloadManager* pSharedManager = NULL;
RuntimeDownloadManager* RuntimeDownloadManager::SharedManager() {
    if (!pSharedManager) {
        pSharedManager = new RuntimeDownloadManager();
    }
    return pSharedManager;
}

RuntimeDownloadManager::RuntimeDownloadManager()
    : downloadDelegate_(NULL),
      download_Option_(kTDownloadOptionInvalid),
      targetScene_(NULL),
      isDownloadStarted_(false),
      download_parameter_(NULL),
      isGvrResourceDownloadCheck_(false),
      isDownloadRetry_(false),
      downloaders_count_(0),
      isResGetApiSending_(false),
      cur_download_index_(0),
      next_download_index_(1),
      isDownloadingPopDisplaying_(false) {
    // ダウンロードパラメーターを取得する
    JOKER::ParameterManager* pm =
        JOKER::JokerApplication::GetInstance()->GetParameterManager();
    this->download_parameter_ = pm->GetDownloadParameter();

    // 初期化
    for (U32 lp = 0; lp < kMaxCurlDlThreads; ++lp) {
        downloaders_[lp] = NULL;
    }
    unziper_ = NULL;

    CCDirector::sharedDirector()->getScheduler()->scheduleSelector(
        schedule_selector(RuntimeDownloadManager::waitForThreadsCompleted),
        this, 0, false);

    CCDirector::sharedDirector()->getScheduler()->pauseTarget(this);
}

RuntimeDownloadManager::~RuntimeDownloadManager() {
    // 都度DL用マネージャー情報をクリアする
    this->clearManagerInfo();

    // 解放
    if (this->unziper_) {
        CC_SAFE_DELETE(this->unziper_);
    }
    for (U32 lp = 0; lp < downloaders_count_; ++lp) {
        CC_SAFE_DELETE(this->downloaders_[lp]);
    }

    CCDirector::sharedDirector()->getScheduler()->unscheduleSelector(
        schedule_selector(RuntimeDownloadManager::waitForThreadsCompleted),
        this);
}

/**
 * @brief 都度DL用のURL情報を初期化する
 */
void RuntimeDownloadManager::initDlResUrlInfo() {
    // API:resource/getのURLの設定
    Chaos::network::ApiInformation* info =
        Chaos::network::ApiInformation::sharedApiInformation();
    this->setApiResGetUrl(
        info->getApiUrl(Chaos::network::ApiInformation::API_URL_RESOURCE_GET));
}

/**
 * @brief 都度DL用マネージャー情報をクリアする
 */
void RuntimeDownloadManager::clearManagerInfo() {
    downloaders_count_ = 0;
    isResGetApiSending_ = false;

    for (U32 lp = 0; lp < kMaxCurlDlThreads; ++lp) {
        CC_SAFE_DELETE(downloaders_[lp]);
        downloaders_[lp] = NULL;
    }
    CC_SAFE_DELETE(unziper_);
    unziper_ = NULL;
}

/**
 * @brief 都度DLをするため、チェック用の情報を追加する
 * @param[in] iCheckFileName チェック用のファイル名
 */
void RuntimeDownloadManager::pushResourceDownloadCheckInfo(
    const char* iCheckFileName) {
    if (!this->download_parameter_) {
        return;
    }
    this->download_parameter_->addCheckDetailInfo(iCheckFileName);
}

/**
 * @brief 都度DLで、ダウンロード用のターゲット情報を追加する
 * @param[in] iResourceType リソースタイプ
 * @param[in] iDetailId 詳細ID
 */
void RuntimeDownloadManager::pushDownloadTargetInfoByDetailId(
    const JOKER::TResourceType iResourceType, const S64 iDetailId) {
    if (!this->download_parameter_) {
        return;
    }
    this->download_parameter_->pushDownloadTargetInfoByDetailId(
        this->cur_download_index_, iResourceType, iDetailId);
}

/**
 * @brief 都度DLが発生するAPIで、ダウンロード用の情報を解析する
 * @param[in] iJsonData JSONデーター
 */
const Bool RuntimeDownloadManager::parseDownloadsInfoByApiResponse(
    const adk::LIB_JsonValue* iJsonData) {
    if (!iJsonData) {
        return false;
    }

    adk::LIB_TJsonMember* ids = (adk::LIB_TJsonMember*)&((*iJsonData)["ids"]);
    const adk::LIB_JsonValue& idsValue = ids->data;
    JOKER_ASSERT_MSG(idsValue.IsArray(), "The array of ids is invalid!!!");

    const int resCnt = idsValue.Size();
    for (S32 i = 0; i < resCnt; ++i) {
        JOKER::TResourceType resourceTypeTmp = JOKER::kTResourceTypeInvalid;
        S32 detailIdTmp = -1;

        const adk::LIB_JsonValue& idValue = idsValue[i];
        if (idValue.IsValid() && (!idValue.IsNull())) {
            const adk::LIB_JsonValue& type = idValue["type"].data;
            if ((type.IsValid()) && (type.IsS32())) {
                resourceTypeTmp = JOKER::TResourceType(type.GetS32());
            }

            const adk::LIB_JsonValue& detailId = idValue["detailId"].data;
            if ((detailId.IsValid()) && (detailId.IsNumber())) {
                detailIdTmp = detailId.GetS64();
            }
        }

        if ((JOKER::kTResourceTypeInvalid != resourceTypeTmp) &&
            (-1 != detailIdTmp)) {
            this->pushDownloadTargetInfoByDetailId(resourceTypeTmp,
                                                   detailIdTmp);
        }
    }

    return true;
}

/**
 * @brief 都度DLが発生するAPIで、ダウンロード用の情報を解析する
 * @param[in] iJsonData JSONデーター
 */
const Bool RuntimeDownloadManager::parseDownloadsInfoByApiResponse(
    CCDictionary* iJsonData) {
    CCArray* ids = dynamic_cast<CCArray*>(iJsonData->objectForKey("ids"));
    if (!ids) {
        return false;
    }

    CCObject* object = NULL;
    CCARRAY_FOREACH(ids, object) {
        CCDictionary* pDownloadInfo = dynamic_cast<CCDictionary*>(object);
        if (!pDownloadInfo) {
            continue;
        }

        // Util::Util::dumpCCDictnaly(pDownloadInfo);

        JOKER::TResourceType resourceTypeTmp = JOKER::kTResourceTypeInvalid;
        S32 detailIdTmp = -1;

        CCNumber* pType =
            dynamic_cast<CCNumber*>(pDownloadInfo->objectForKey("type"));
        if (pType) {
            resourceTypeTmp = JOKER::TResourceType(pType->getIntValue());
        }

        CCNumber* pDetailId =
            dynamic_cast<CCNumber*>(pDownloadInfo->objectForKey("detailId"));
        if (pDetailId) {
            detailIdTmp = pDetailId->getIntValue();
        }

        if ((JOKER::kTResourceTypeInvalid != resourceTypeTmp) &&
            (-1 != detailIdTmp)) {
            this->pushDownloadTargetInfoByDetailId(resourceTypeTmp,
                                                   detailIdTmp);
        }
    }

    return true;
}

/**
 * @brief 「Api:/api/resource/get」のレスポンスデータ解析関数
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iJsonData JSONデータ
 * @return true : 設定成功; false : 設定失敗、または、データなしの場合;
 */
const Bool RuntimeDownloadManager::parseResourceGetResponseData(
    const S32 iDownloadIndex, const adk::LIB_JsonValue* iJsonData) const {
    if (!this->download_parameter_) {
        return false;
    }

    const int resCnt = iJsonData->Size();
    adk4app::dumpLIB_JsonValue(*iJsonData, "Download Resource List", 0);

    JOKER_ASSERT_MSG(iJsonData->IsArray(),
                     "The download list is not a array!!!");
    for (S32 i = 0; i < resCnt; ++i) {
        const adk::LIB_JsonValue resourceId = (*iJsonData)[i];
        if ((resourceId.IsValid()) && (resourceId.IsNumber())) {
            S32 resourceIdTmp = resourceId.GetS32();
            // ターゲット追加
            this->download_parameter_->pushDownloadTargetInfo(iDownloadIndex,
                                                              resourceIdTmp);
        }
    }

    return true;
}

/**
 * @brief リソースのテクスチャを取得する
 * @param[in] iTextureName リソースのテクスチャ名
 * @param[in] iIsDummyFlg ダミーフラグ
 */
cocos2d::CCSprite* RuntimeDownloadManager::getResSprite(
    const char* iTextureName, Bool& iIsDummyFlg) {
    cocos2d::CCSprite* retTmp = NULL;

    // 初期化
    retTmp = cocos2d::CCSprite::create();
    if (!retTmp) {
        iIsDummyFlg = false;
        CC_SAFE_DELETE(retTmp);
        JOKER_ASSERT_MSG(retTmp, "CCSprite Create Failed!!!");
        return NULL;
    }
    this->isDownloadStarted_ = false;
    iIsDummyFlg = this->getResTexture(iTextureName, retTmp);

    return retTmp;
}

/**
 * @brief リソースのテクスチャを取得する
 * @param[in] iTextureName リソースのテクスチャ名
 * @param[in] iTargetSprite ターゲットスプライト
 * @param[in] iAddCheckAPIFlg
 * チェック用のAPI(resource/get)が発生するかどうかのフラグ
 * @return ダミーフラグ
 */
Bool RuntimeDownloadManager::getResTexture(const char* iTextureName,
                                           CCSprite* iTargetSprite,
                                           Bool iAddCheckAPIFlg) {
    // リソースファイルの存在チェック
    if (this->isResourceFileExist(iTextureName)) {
        // ダミーフラグの設定
        CCTexture2D* retTmp =
            CCTextureCache::sharedTextureCache()->addImage(iTextureName);

        // スプライトを再初期化にする
        iTargetSprite->initWithTexture(retTmp);
    } else {
        // テクスチャーがすでに未設定場合のみ、ダミーテクスチャーを設定する
        if (iTargetSprite->getTexture() == NULL) {
            // 表示するため、先にダミー画像を用意して、裏で都合ダウンロードを行う
            CCTexture2D* retTmp =
                CCTextureCache::sharedTextureCache()->addImage(
                    DUMMY_IMAGE_NAME);

            // スプライトを再初期化にする(ダミー画像で)
            iTargetSprite->initWithTexture(retTmp);
        }

        // 都度DLで、サーバーへ、問い合わせるため(API:resource/get)、検索用のテクスチャーファイル名を追加する
        if (iAddCheckAPIFlg) {
            this->pushResourceDownloadCheckInfo(iTextureName);
        }

        // ダミーフラグの設定
        return true;
    }

    return false;
}

/**
 * @brief ダウンロード用のターゲットズ情報をクリーンアップする
 */
void RuntimeDownloadManager::CleanUpDownloadTargetsInfo() {
    if (!this->download_parameter_) {
        return;
    }

    this->download_parameter_->clearDownloadDetailsByCurrentDownloadIndex(
        this->cur_download_index_);
}

/**
 * @brief スレッドズをチェックして、完了する前
 * @param[in] iDeltaTime
 */
void RuntimeDownloadManager::waitForThreadsCompleted(F32 iDeltaTime) {
    if (!this->download_parameter_) {
        CCDirector::sharedDirector()->getScheduler()->unscheduleSelector(
            schedule_selector(RuntimeDownloadManager::waitForThreadsCompleted),
            this);

        // ダウンロード用のターゲットズ情報をクリーンアップする
        this->CleanUpDownloadTargetsInfo();

        return;
    }

    // 全スレッドが止まる時
    if (this->isAllThreadStoped()) {
        // ダウンロード用のターゲットズ情報をクリーンアップする
        this->CleanUpDownloadTargetsInfo();
    }

    // ダウンロードが実行不可の場合
    if (!this->isDownloadExecutable()) {
        return;
    }

    // 都度DL用マネージャー情報をクリアする
    this->clearManagerInfo();

    switch (this->download_Option_) {
        case kTDownloadOptionNormal: {
            // ダウンロードターゲットがない場合
            S32 targets_count =
                this->download_parameter_->getDownloadTargetsCount(
                    this->cur_download_index_);
            if (0 >= targets_count) {
                CCDirector::sharedDirector()->getScheduler()->pauseTarget(this);
                return;
            }

            // 開始する前に、URL情報を初期化する
            this->initDlResUrlInfo();

            // ローディングパールの追加
            if (this->targetScene_) {
                this->addLoadingParts(this->targetScene_,
                                      this->cur_download_index_);
                this->isDownloadingPopDisplaying_ = true;
            }

            // チェック情報がある場合
            if (this->isCheckDetailInfoExistByFilePath()) {
                IntPtr handle =
                    adk::LIB_ThreadCreate(sentResourceGetRequest, this, false);
                JOKER_ASSERT_MSG(
                    handle,
                    "RuntimeDownloadManager::waitForThreadsCompleted "
                    "thread failure!!\n");
            } else {
                this->BeginDownload();
            }

        } break;

        case kTDownloadOptionAll: {
            // 一括DL用のターゲットズ一覧を作成する
            this->download_parameter_->createRuntimeDownloadTargetsForAll(
                this->cur_download_index_);

            // 都度DL検索用リソースファイル名がない場合、戻す
            if (!this->download_parameter_->isDownloadTargetsExist(
                    this->cur_download_index_, false) &&
                this->downloadDelegate_) {
                this->downloadDelegate_->downloadWhenNoTargetResource();
                break;
            }

            // ローディングパールの追加
            if (this->targetScene_) {
                this->addLoadingParts(this->targetScene_,
                                      this->cur_download_index_, true);
                this->isDownloadingPopDisplaying_ = true;
            }

            // リソースファイル(Zip)ダウンロードスレッドを開始する
            this->BeginDownload();

        } break;
        default:
            break;
    }

    CCDirector::sharedDirector()->getScheduler()->pauseTarget(this);
}

/**
 * @brief リソース情報を取得するため、問い合わせるリクエストを投げる
 * @param[in] iDlResManager 都度DL専用のリソースマネージャー
 */
void RuntimeDownloadManager::sentResourceGetRequest(void* iDlResManager) {
    RuntimeDownloadManager* self = (RuntimeDownloadManager*)iDlResManager;
    if (self == NULL) {
        return;
    }
    if (!self->download_parameter_) {
        return;
    }

    self->isResGetApiSending_ = true;
    self->isDownloadStarted_ = true;
    self->download_parameter_->lockAddCheckDetail();
    // コールバックの設定
    JOKER::ApiResourceGet::SharedApi()->SetCallback(
        self, (JOKER::ApiResourceGet::TCallback)&RuntimeDownloadManager::
                  CompeletedGetResInfoByFileName);

    // リクエストを投げる
    JOKER::TDownloadCheckDetailsInfo checkDetailsTmp =
        self->download_parameter_->getDownloadCheckDetails();
    JOKER::ApiResourceGet::SharedApi()->Request(checkDetailsTmp);
    self->download_parameter_->clearDownloadCheckDetails();
}

/**
 * @brief リソース情報を取得する問い合わせるリクエストが返してくるコールバック
 * @param[in] iIsSuccessFlg 通信成功フラグ
 * @param[in] iResInfoData リソース情報データ
 */
Bool RuntimeDownloadManager::CompeletedGetResInfoByFileName(
    Bool iIsSuccessFlg, const adk::LIB_JsonValue* iResInfoData) {
    if (!this->download_parameter_) {
        return false;
    }

    // 通信失敗の場合
    if (iIsSuccessFlg == false) {
        // ローディングパーツを消す
        this->removeLoadingParts();
        this->isResGetApiSending_ = false;

        this->download_parameter_->clearDownloadCheckDetails();
        this->download_parameter_->unlockAddCheckDetail();
        return false;
    }

    // 都度DL用のリソース情報を設定する
    if (this->parseResourceGetResponseData(this->cur_download_index_,
                                           iResInfoData) == false) {
        // ローディングパーツを消す
        this->removeLoadingParts();
        this->isResGetApiSending_ = false;

        this->download_parameter_->clearDownloadCheckDetails();
        this->download_parameter_->unlockAddCheckDetail();

        return false;
    }

    // リソースファイル(Zip)ダウンロードスレッドを開始する
    this->BeginDownload();

    this->isResGetApiSending_ = false;
    this->download_parameter_->unlockAddCheckDetail();
    // 成功の場合
    return true;
}

/**
 * @brief 都度DLで、ローディングパーツを消す
 */
void RuntimeDownloadManager::removeLoadingParts() {
    if (!this->targetScene_) {
        return;
    }
    this->targetScene_->removeChildByTag(DL_PARTS_LOADING_TAG);
}

#pragma mark -
#pragma mark v3.12.0から、改修

/**
 * @brief 都度DLスレッドを開始する
 * @param[in] iTargetScene ターゲットシーン
 * @param[in] iDownloadDegelage ダウンロードデリゲート
 */
void RuntimeDownloadManager::StartUpDownloadThread(
    CCNode* iTargetScene, RuntimeDownloadManagerDelegate* iDownloadDegelage) {
    if (!this->download_parameter_) {
        return;
    }

    // ダウンロードがまだ、実行中の場合
    if (this->isDownloadExecuting()) {
        return;
    }

    if (iTargetScene) {
        this->targetScene_ = iTargetScene;
    } else {
        this->targetScene_ = this->getDownloadTargetScene();
    }

    JOKER_DEBUG(
        "\n[Debug:C I/A]RuntimeDownloadManager::StartUpDownloadThread\n");

    // リトライフラグを落とす
    this->isDownloadRetry_ = false;

    // デリゲート
    this->downloadDelegate_ = iDownloadDegelage;

    // スレッドを起動するため、スケジュールを開始する
    this->download_Option_ = kTDownloadOptionNormal;
    CCDirector::sharedDirector()->getScheduler()->resumeTarget(this);
}

/**
 * @brief
 * 都度DLスレッドを開始する(一括DLオプションより、残るリソースをダウンロードする)
 * @param[in] iTargetScene ターゲットシーン
 * @param[in] iDownloadDegelage ダウンロードデリゲート
 * @return ダウンロード用のリソース数
 */
void RuntimeDownloadManager::StartUpDownloadForAllThread(
    CCNode* iTargetScene, RuntimeDownloadManagerDelegate* iDownloadDegelage) {
    if (!this->download_parameter_) {
        return;
    }

    if (iTargetScene) {
        this->targetScene_ = iTargetScene;
    } else {
        this->targetScene_ = this->getDownloadTargetScene();
    }

    // リトライフラグを落とす
    this->isDownloadRetry_ = false;

    // デリゲート
    this->downloadDelegate_ = iDownloadDegelage;

    // スレッドを起動するため、スケジュールを開始する
    this->download_Option_ = kTDownloadOptionAll;
    CCDirector::sharedDirector()->getScheduler()->resumeTarget(this);
}

/**
 * @brief ローカルDBへ、ダウンロードリソース一覧情報を退避するスレッドを起動する
 */
void RuntimeDownloadManager::StartUpSaveToLocalDBThread() {
    if (!this->download_parameter_) {
        return;
    }
    // リソースが既に全件退避された場合、スキップする
    if (this->download_parameter_->hadAllResourcesInfoSavedToLocalDB()) {
        return;
    }

    // ダウンロード情報をローカルDBへ退避するスレッドを生成して、開始する
    IntPtr handle =
        adk::LIB_ThreadCreate(startSaveDlResInfoToLocalDB, this, false);
    JOKER_ASSERT_MSG(handle,
                     "RuntimeDownloadManager::"
                     "StartUpSaveDlResInfoToLocalDBThread thread failure!!\n");
}

/**
 * @brief ダウンロード用のリソース一覧情報をローカルDBへの退避することを開始する
 * @param[in] iDlResManager 都度DL専用のリソースマネージャー
 */
void RuntimeDownloadManager::startSaveDlResInfoToLocalDB(void* iDlResManager) {
    RuntimeDownloadManager* self = (RuntimeDownloadManager*)iDlResManager;
    if (self == NULL) {
        return;
    }

    while (!self->download_parameter_->hadAllResourcesInfoSavedToLocalDB()) {
        self->download_parameter_->saveAllResourcesInfoToLocalDB();
    }
}

/**
 * @brief 都度DLで、ダウンロード中を示すため、ローディングパーツを追加する
 * @param[in] iTargetScene ターゲットシーン
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iDownloadIndexAutoResetFlg
 * ダウンロードインデックス自動リセットフラグ
 * @return true : 追加されました; false : 追加されなかった;
 */
Bool RuntimeDownloadManager::addLoadingParts(
    CCNode* iTargetScene, const S32 iDownloadIndex,
    const Bool iDownloadIndexAutoResetFlg) {
    if (!iTargetScene) {
        return false;
    }
    CCNode* loader = iTargetScene->getChildByTag(DL_PARTS_LOADING_TAG);
    if (!loader) {
        loader = Chaos::Util::Util::loadCustomParts(
            "CCBPartsDlResLoading",
            Chaos::CCB::Parts::CCBPartsDlResLoadingBuilderLoader::loader());
        if (!loader) {
            return false;
        }
        // ダウンロードインデックスの指定
        Chaos::CCB::Parts::CCBPartsDlResLoading* pLoadingParts =
            dynamic_cast<Chaos::CCB::Parts::CCBPartsDlResLoading*>(loader);
        if (pLoadingParts) {
            pLoadingParts->setDownloadIndex(iDownloadIndex);
            pLoadingParts->setDownloadIndexAutoResetFlg(
                iDownloadIndexAutoResetFlg);
        }

        iTargetScene->addChild(loader, DL_PARTS_LOADING_ZORDER,
                               DL_PARTS_LOADING_TAG);
    }
    return true;
}

/**
 * @brief リソースファイルの存在チェック
 * @param[in] iResFileName リソースファイル名
 */
bool RuntimeDownloadManager::isResourceFileExist(const char* iResFileName) {
    if (!this->download_parameter_) {
        return false;
    }
    return this->download_parameter_->isFileExist(iResFileName);
}

/**
 * @brief 全スレッドが止まってるかどうかのチェックを行う
 * @return 全スレッド止まるフラグ
 */
const Bool RuntimeDownloadManager::isAllThreadStoped() {
    if (!this->isDownloadStoped()) {
        return false;
    }

    // 解凍者もチェックする
    if (this->unziper_) {
        if (!this->unziper_->isStoped()) {
            return false;
        }
    }
    return true;
}

/**
 * @brief
 * ローカルDBへ、すでにダウンロードされたリソースカード情報をリセットする(デバッグ機能のみ、使う)
 * @param[in] iCardId 詳細ID
 */
const void
RuntimeDownloadManager::resetRuntimeDownloadCardResourceInfoToLocalDB(
    const S32 iCardId) {
    if (!this->download_parameter_) {
        return;
    }
    // パラメーターへ更新
    this->download_parameter_->resetRuntimeDownloadResourceInfoToParameter(
        JOKER::kTResourceTypeCard, iCardId);
    // ローカルDBへ更新
    this->download_parameter_->resetRuntimeDownloadResourceInfoToLocalDB(
        JOKER::kTResourceTypeCard, iCardId);
}

/**
 * @brief ダウンロードが実行中であるどうかの判定
 * @return ダウンロードの実行中フラグ
 */
const Bool RuntimeDownloadManager::isDownloadExecuting() const {
    Bool isExecuting = this->isResGetApiSending_;
    if (isExecuting) {
        return true;
    }

    for (U32 lp = 0; lp < downloaders_count_; ++lp) {
        if (!downloaders_[lp]) {
            continue;
        }

        if (downloaders_[lp]->isConnecting()) {
            continue;
        }

        isExecuting = !downloaders_[lp]->isStoped();
        if (isExecuting) {
            return true;
        }
    }

    //    if (!isAllConnecting) {
    //        // 解凍者もチェックする
    //        if (this->unziper_) {
    //            isRuning = !this->unziper_->isStoped();
    //            if (isRuning) {
    //                return true;
    //            }
    //        }
    //    }
    return false;
}

/**
 * @brief ダウンロードが実行できるかどうかの判定
 * @return ダウンロードの実行できるフラグ
 */
const Bool RuntimeDownloadManager::isDownloadExecutable() const {
    // リトライの場合
    if (this->isDownloadRetry_) {
        for (U32 lp = 0; lp < downloaders_count_; ++lp) {
            if (!downloaders_[lp]) {
                continue;
            }
            if (downloaders_[lp]->isStoped()) {
                return true;
            }
        }
        return false;
    } else {
        bool isExcuting = this->isDownloadExecuting();
        if (isExcuting) {
            return false;
        }
        return true;
    }
}

/**
 * @brief ダウンロードが必要かどうかのチェックを行う
 * @return ダウンロードの必要フラグ
 */
const Bool RuntimeDownloadManager::isDownloadNecessary() const {
    if (!this->download_parameter_) {
        return false;
    }
    if (this->download_parameter_->isCheckDetailInfoExist()) {
        return true;
    }
    if (this->download_parameter_->getDownloadTargetsCount(
            this->cur_download_index_)) {
        return true;
    }
    return false;
}

/**
 * @brief チェック詳細情報の存在チェックを行う
 * @return チェック詳細情報の存在フラグ
 */
const Bool RuntimeDownloadManager::isCheckDetailInfoExist() const {
    if (!this->download_parameter_) {
        return false;
    }
    return this->download_parameter_->isCheckDetailInfoExist();
}

/**
 * @brief チェック詳細情報(ファイルパスで)の存在チェックを行う
 * @return チェック詳細情報(ファイルパスで)の存在フラグ
 */
const Bool RuntimeDownloadManager::isCheckDetailInfoExistByFilePath() const {
    if (!this->download_parameter_) {
        return false;
    }
    return this->download_parameter_->isCheckDetailInfoExistByFilePath();
}

/**
 * @brief ダウンロード用のターゲットシーンを取得する
 * @return ダウンロード用のターゲットシーン
 */
CCScene* RuntimeDownloadManager::getDownloadTargetScene() {
    CCScene* transition_scene =
        CCDirector::sharedDirector()->GetTransitionFaterScene();
    CCScene* nextscene = CCDirector::sharedDirector()->getNextScene();
    CCScene* curr_scene = transition_scene;

    if (curr_scene == NULL) {
        curr_scene = (nextscene != NULL)
                         ? nextscene
                         : CCDirector::sharedDirector()->getRunningScene();
    }
    return curr_scene;
}

/**
 * @brief リソースファイル(Zip)のダウンロードを開始する
 */
void RuntimeDownloadManager::BeginDownload() {
    if (!this->download_parameter_) {
        return;
    }

    JOKER_DEBUG(
        "\n[Debug:C "
        "I/"
        "A]RuntimeDownloadManager::BeginDownload::DownloadIndex:%d",
        this->cur_download_index_);

    // ダウンロードのターゲットズカウンター
    S32 targets_count = this->download_parameter_->getDownloadTargetsCount(
        this->cur_download_index_);
    if (0 >= targets_count) {
        JOKER_DEBUG(
            "\n[Debug:C "
            "I/"
            "A]RuntimeDownloadManager::BeginDownload::DownloadIndex:%d -> No "
            "Download Target!!!",
            this->cur_download_index_);
        return;
    }

    // 解凍者を生成する
    if (!this->unziper_) {
        this->unziper_ = Unziper::create(this->cur_download_index_, false);
        JOKER_ASSERT_MSG(this->unziper_, "The Unziper create failded!!!");
    } else {
        this->unziper_->Reset(this->cur_download_index_, false);
    }
    this->unziper_->StartUnzip();

    // 都度DL専用のダウンロードスレッドを開始する
    this->downloaders_count_ = MIN(kMaxCurlDlThreads, targets_count);
    for (U32 lp = 0; lp < downloaders_count_; ++lp) {
        if (!downloaders_[lp]) {
            JOKER_DEBUG(
                "\n[Debug:C "
                "I/"
                "A]RuntimeDownloadManager::BeginDownload::downloaders[%d]::"
                "create",
                lp);
            downloaders_[lp] = Downloader::create(
                this->unziper_, lp, this->cur_download_index_, false);
            JOKER_ASSERT_MSG(downloaders_[lp],
                             "The Downloader create failded!!!");
        } else {
            JOKER_DEBUG(
                "\n[Debug:C "
                "I/"
                "A]RuntimeDownloadManager::BeginDownload::downloaders[%d]::"
                "Reset",
                lp);
            downloaders_[lp]->Reset(this->cur_download_index_, false);
        }
        downloaders_[lp]->StartDownload();
    }

    this->isDownloadStarted_ = true;
}

/**
 * @brief 都度DLの進捗率を取得する
 * @return 都度DLの進捗率
 */
const F32 RuntimeDownloadManager::GetDownloadProgressRate() const {
    if (!this->download_parameter_) {
        return 0.0f;
    }
    const JOKER::TDownloadedCountInfo countInfo =
        this->download_parameter_->getDownloadedCountInfo(
            this->cur_download_index_);
    return countInfo.completed_rate;
}

/**
 * @brief 都度DLをキャンセルする
 */
const void RuntimeDownloadManager::Cancel() {
    for (U32 lp = 0; lp < downloaders_count_; ++lp) {
        if (!downloaders_[lp]) {
            continue;
        }
        downloaders_[lp]->Cancel();
    }

    if (this->unziper_) {
        this->unziper_->Cancel();
    }

    if (downloadDelegate_ != NULL) {
        downloadDelegate_->DownloadCancel();
    }

    // ダウンロードインデックスをリセットする
    this->resetDownloadIndex();
}

/**
 * @brief 都度DLをリトライする
 */
const void RuntimeDownloadManager::Retry() {
    // リトライ
    this->isDownloadRetry_ = true;

    for (U32 lp = 0; lp < downloaders_count_; ++lp) {
        if (!downloaders_[lp]) {
            continue;
        }
        downloaders_[lp]->Retry();
    }
}

/**
 * @brief ダウンローダーには、通信失敗があるかどうかの判定
 * @return 通信失敗フラグ
 */
const Bool RuntimeDownloadManager::isDownloaderFailed() {
    if (0 >= downloaders_count_) {
        return false;
    } else {
        for (U32 lp = 0; lp < downloaders_count_; ++lp) {
            if (!downloaders_[lp]) {
                continue;
            }
            if (downloaders_[lp]->isFailed()) {
                return true;
            }
        }
    }
    return false;
}

/**
 * @brief 都度DLには、リトライできるかどうかのチェック
 */
const Bool RuntimeDownloadManager::isDownloadRetryAble() const {
    for (U32 lp = 0; lp < downloaders_count_; ++lp) {
        if (!downloaders_[lp]) {
            continue;
        }
        if (downloaders_[lp]->isRetryAble()) {
            return true;
        }
    }
    return false;
}

/**
 * @brief 前回のリソース更新日付を設定する
 * @param[in] iLastResourceUpdateDate 前回のリソース更新日付
 */
const void RuntimeDownloadManager::SetLastResourceDate(
    const S64 iLastResourceUpdateDate) {
    if (!this->download_parameter_) {
        return;
    }
    this->download_parameter_->SetLastResourceDate(iLastResourceUpdateDate);
}

/**
 * @brief 前回のリソース情報を設定する
 * @param[in] iLastResourceId 前回のリソースID
 * @param[in] iLastResourceUpdateDate 前回のリソース更新日付
 */
const void RuntimeDownloadManager::SetLastResourceInfo(
    const S32 iLastResourceId, const S64 iLastResourceUpdateDate) {
    if (!this->download_parameter_) {
        return;
    }
    this->download_parameter_->SetLastResourceInfo(iLastResourceId,
                                                   iLastResourceUpdateDate);
}

/**
 * @brief 前回のリソース情報を保存する
 */
const void RuntimeDownloadManager::SaveLastResourceInfo() {
    if (!this->download_parameter_) {
        return;
    }
    this->download_parameter_->saveLastResourceInfo();
}

/**
 * @brief
 * 指定されたリソースのみ、ダウンロードが完了されたかどうかのチェックを行う
 * @param[in] iCheckType チェックタイプ
 * @param[in] iCheckDetailId チェック用のID
 * @param[in] iIsDownloadAutoAdd ダウンロード対象に自動追加フラグ
 *           （trueの場合、自動で、ダウンロードターゲットズリストへ追加する）
 * @return ダウンロードの完了フラグ
 */
const Bool RuntimeDownloadManager::isDownloadedCompletedByDetailId(
    const JOKER::TResourceType iCheckType, const S32 iCheckDetailId,
    const Bool iIsDownloadAutoAdd) {
    Bool bolRet = true;
    if (-1 >= iCheckDetailId) {
        return bolRet;
    }

    if (!this->download_parameter_) {
        return bolRet;
    }

    // 未ダウンロードの場合
    if (!this->download_parameter_->isResourceDownloadedByDetailId(
            iCheckType, iCheckDetailId)) {
        bolRet = false;

        // 自動追加の場合、ダウンロードターゲットズへ追加する
        if (iIsDownloadAutoAdd) {
            this->download_parameter_->pushDownloadTargetInfoByDetailId(
                this->cur_download_index_, iCheckType, iCheckDetailId);
        }
    }

    // 自動追加以外で、かつ、ダウンロード中のPOPがまだ表示中の場合
    if (!iIsDownloadAutoAdd && this->isDownloadingPopDisplaying_) {
        return false;
    } else {
        // ダウンロードが完了、かつ、自動追加ではない場合、
        // ダウンロードインデックスをリセットする
        if (bolRet && !iIsDownloadAutoAdd) {
            this->resetDownloadIndex();
        }
        return bolRet;
    }
}

/**
 * @brief
 * 指定されたリソースのみ、ダウンロードが完了されたかどうかのチェックを行う
 * @param[in] iCheckType チェックタイプ
 * @param[in] iCheckDetailIds チェック用のID詳細一覧
 * @param[in] iIsDownloadAutoAdd ダウンロード対象に自動追加フラグ
 *           （trueの場合、自動で、ダウンロードターゲットズリストへ追加する）
 * @return ダウンロードの完了フラグ
 */
const Bool RuntimeDownloadManager::isDownloadAllCompletedByDetailIds(
    const JOKER::TResourceType iCheckType,
    const std::vector<S32>* iCheckDetailIds, const Bool iIsDownloadAutoAdd) {
    Bool bolRet = true;
    if (!iCheckDetailIds) {
        return bolRet;
    }

    if (0 >= ((S32)iCheckDetailIds->size())) {
        return bolRet;
    }

    if (!this->download_parameter_) {
        return bolRet;
    }

    std::vector<S32>::const_iterator itBegin = iCheckDetailIds->begin();
    std::vector<S32>::const_iterator itEnd = iCheckDetailIds->end();
    for (std::vector<S32>::const_iterator itLoop = itBegin; itLoop != itEnd;
         ++itLoop) {
        const S32 checkDetailId = (*itLoop);

        // 未ダウンロードの場合
        if (!this->download_parameter_->isResourceDownloadedByDetailId(
                iCheckType, checkDetailId)) {
            bolRet = false;

            // 自動追加の場合、ダウンロードターゲットズへ追加する
            if (iIsDownloadAutoAdd) {
                this->download_parameter_->pushDownloadTargetInfoByDetailId(
                    this->cur_download_index_, iCheckType, checkDetailId);
            }
        }

        // 自動追加以外、かつ、未ダウンロードがある場合
        if ((!iIsDownloadAutoAdd) && (!bolRet)) {
            break;
        }
    }

    // 自動追加以外で、かつ、ダウンロード中のPOPがまだ表示中の場合
    if (!iIsDownloadAutoAdd && this->isDownloadingPopDisplaying_) {
        return false;
    } else {
        // ダウンロードが完了、かつ、自動追加ではない場合、ダウンロードインデックスをリセットする
        if (bolRet && !iIsDownloadAutoAdd) {
            this->resetDownloadIndex();
        }
        return bolRet;
    }
}

/**
 * @brief
 * 指定されたリソースのみ、ダウンロードが完了されたかどうかのチェックを行う
 * @param[in] iDownloadIndexForceResetFlg
 * ダウンロードインデックス強制リセットフラグ
 * @return ダウンロードの完了フラグ
 */
const Bool RuntimeDownloadManager::isDownloadedCompleted() {
    const JOKER::TDownloadedCountInfo countInfo =
        this->getDownloadedCountInfo();
    Bool bolRet = (countInfo.completed_rate >= 1.0f);

    // ダウンロード中のPOPがまだ表示中の場合
    if (this->isDownloadingPopDisplaying_) {
        return false;
    } else {
        // ダウンロードが完了の場合、ダウンロードインデックスをリセットする
        if (bolRet) {
            this->resetDownloadIndex();
        }
        return bolRet;
    }
}

/**
 * @brief カードのリソースダウンロードが完了されたかどうかのチェックを行う
 *        注意事項：ダウンロードインデックスをリセットしない
 * @return ダウンロードの完了フラグ
 */
const Bool RuntimeDownloadManager::isCardDownloadedCompletedByID(
    const S32 iCardId) {
    if (!this->download_parameter_) {
        return false;
    }

    const JOKER::TResourceInfo* resourceInfo =
        this->download_parameter_->getResourceInfoWithReadOnly(
            JOKER::kTResourceTypeCard, (S64)iCardId);
    if (resourceInfo) {
        return resourceInfo->unziped_;
    }

    return false;
}
}
}