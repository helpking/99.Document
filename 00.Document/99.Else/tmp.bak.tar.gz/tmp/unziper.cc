//
//  unziper.cpp
//  chaos
//
//  Created by 何 利強 on 2016/09/06.
//
//

#include "ResourcesManager/unziper.h"

#include "ResourcesManager.h"
#include "application/joker_application.h"
#include "parameter/parameter_manager.h"

namespace Chaos {
namespace ResourcesManager {

/**
 * @brief 解凍者を作成する
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iIsBackgroundDownload バックグラウンドDLフラグ
 */
Unziper* Unziper::create(const S32 iDownloadIndex,
                         const Bool iIsBackgroundDownload) {
    Unziper* pRet = new Unziper();
    if (pRet) {
        pRet->SetDownloadInfo(iDownloadIndex, iIsBackgroundDownload);
        return pRet;
    } else {
        CC_SAFE_DELETE(pRet);
        pRet = NULL;
    }
    return NULL;
}

Unziper::Unziper()
    : thread_(NULL),
      download_parameter_(NULL),
      isCanceled_(false),
      state_(kTUnzipStateIdle),
      isBackgroundDownload_(false),
      download_index_(-1),
      unzip_index_(-1) {
    // ダウンロードパラメーターを取得する
    JOKER::ParameterManager* pm =
        JOKER::JokerApplication::GetInstance()->GetParameterManager();
    this->download_parameter_ = pm->GetDownloadParameter();
}

Unziper::~Unziper() {
    // 解放する前に、無限ループでスレッドをチェックする
    while (true) {
        if (this->isStoped()) {
            break;
        }
        // 待機中の場合
        if (this->isPausing()) {
            this->Continue();
        }
        usleep(1000);
    }
}

/**
 * @brief 解凍を開始する
 */
const void Unziper::StartUnzip() {
    
    // 解凍インデックスを初期化にする
    this->unzip_index_ = 0;
    
    JOKER_DEBUG("\n[Debug:C I/A][%d/%d]Unziper::StartUnzip",
                this->download_index_, this->unzip_index_);
    
    // スレッド
    pthread_mutex_init(&sleep_mutex_, NULL);
    pthread_cond_init(&sleep_condition_, NULL);

    // スレッドで ダウンロードしたファイルのunzip展開 を開始
    JOKER_ASSERT(!this->thread_);
    pthread_create(&this->thread_, NULL, Unzip, this);
    pthread_detach(this->thread_);
}

/**
 * @brief 停止してるかどうかのチェック
 * @return 停止フラグ
 */
Bool Unziper::isStoped() {
    if (kTUnzipStateCompleted > this->state_) {
        return false;
    }

    // スレッドでチェック
    if (thread_) {
        return false;
    }

    return true;
}

/**
 * @brief 解凍を一時停止にする
 */
const void Unziper::Pause() {
    // ステートを設定する
    this->state_ = kTUnzipStatePausing;
}

/**
 * @brief 解凍を続く
 */
const void Unziper::Continue() {
    // 解凍を続行する
    pthread_cond_signal(&sleep_condition_);
}

/**
 * @brief 解凍をリセットする
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iIsBackgroundDownload バックグラウンドDLフラグ
 */
const void Unziper::Reset(const S32 iDownloadIndex,
                          const Bool iIsBackgroundDownload) {
    this->SetDownloadInfo(iDownloadIndex, iIsBackgroundDownload);
    // ステートを設定する
    //    this->state_ = kTUnzipStateIdle;
}

/**
 * @brief 解凍をキャンセルする
 */
const void Unziper::Cancel() {
    this->isCanceled_ = true;

    // 解凍を続行する
    if (this->isPausing()) {
        this->Continue();
    }
}

/**
 * \brief ファイルを解凍する
 * \param[in] iUnziper 解凍者
 */
void* Unziper::Unzip(void* iUnziper) {
    Unziper* self = (Unziper*)iUnziper;
    if (self == NULL) {
        return NULL;
    }

    if (!self->download_parameter_) {
        return NULL;
    }

    // キャンセルされない場合、解凍を続行する
    while (!self->isCanceled()) {
        JOKER::TResourceInfo* pCurrentUnzipTarget =
            self->download_parameter_->getUnzipTargetInfo(
                self->getDownloadIndex(), self->unzip_index_,
                self->isBackgroundDownload_);

        // ターゲットがない場合
        if (!pCurrentUnzipTarget) {
            break;
        }

        // 一時停止の場合、待機
        while (self->isPausing()) {
            // ステートの設定
            self->state_ = kTUnzipStatePausing;
            pthread_cond_wait(&self->sleep_condition_, &self->sleep_mutex_);
        }

        // キャンセルされた場合、スキップする
        if (self->isCanceled()) {
            break;
        }

        // 全件既に解凍された場合
        if (self->download_parameter_->isAllTargetsUnziped(
                self->getDownloadIndex(), self->isBackgroundDownload_)) {
            break;
        }

        // カレントターゲットは、ダウンロードがまだ終わってない場合、待機
        while (!pCurrentUnzipTarget->downloaded_) {
            // ステートの設定
            self->state_ = kTUnzipStateWaiting;
            pthread_cond_wait(&self->sleep_condition_, &self->sleep_mutex_);

            pCurrentUnzipTarget =
                self->download_parameter_->getResourceInfoWithWritable(
                    pCurrentUnzipTarget->resourceId_);

            usleep(100);
        }

        // キャンセルされた場合、スキップする
        if (self->isCanceled()) {
            break;
        }

        // カレントターゲットは、解凍済みの場合
        if (pCurrentUnzipTarget->unziped_) {
            ++self->unzip_index_;
            continue;
        }

        // ステートの設定
        self->state_ = kTUnzipStateUnziping;

        // ファイルを解凍する
        // ファイル名抽出
        const std::string unzipFilename(
            strrchr(pCurrentUnzipTarget->downloadUrl_.c_str(), '/') + 1);

        JOKER_DEBUG(
            "\n[Debug:C I/A][%d/%d][DlResource]Unziper::Unzip::[Start]ID[%d] "
            "[%6.1f KB] "
            "file:%s\n",
            self->download_index_, self->unzip_index_, pCurrentUnzipTarget->resourceId_,
            pCurrentUnzipTarget->dataSize_ / 1024.0, unzipFilename.c_str());

        // ファイルを保存するまで、無限リトライ
        while (
            !Chaos::ResourcesManager::ResourcesManager::sharedResourcesManager()
                 ->saveFile(pCurrentUnzipTarget->data_,
                            pCurrentUnzipTarget->dataSize_, unzipFilename)) {
            self->state_ = kTUnzipStatePausing;
            pthread_cond_wait(&self->sleep_condition_, &self->sleep_mutex_);
        }
        free(pCurrentUnzipTarget->data_);
        pCurrentUnzipTarget->data_ = NULL;
        
        // 解凍インデックスをカウントする
        ++self->unzip_index_;

        // 都度DL成功したので、ローカルDBへ更新する
        self->download_parameter_->updateResourceInfoWhenUnziped(
            self->getDownloadIndex(), self->unzip_index_, pCurrentUnzipTarget->resourceId_);

        usleep(100);
    }

    self->thread_ = NULL;
    pthread_mutex_destroy(&self->sleep_mutex_);
    pthread_cond_destroy(&self->sleep_condition_);

    // ステートを設定する
    self->state_ = kTUnzipStateCompleted;

    return NULL;
}
}
}
