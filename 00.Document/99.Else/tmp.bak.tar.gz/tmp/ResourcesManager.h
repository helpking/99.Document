//
//  ResourcesManager.h
//  chaos
//
//  Created by B02892 on 13/04/10.
//
//

#ifndef __chaos__ResourcesManager__
#define __chaos__ResourcesManager__

#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"
#include "Common.h"
#include "CCHttpNetwork.h"

#include "SQLiteC++.h"
#include "parameter/download_parameter.h"

namespace Chaos {
namespace ResourcesManager {
    
    
    class ResourcesManager
    : public cocos2d::CCObject
    
    {
    public:
        virtual ~ResourcesManager();
        
        /**
         * Singleton
         */
        static ResourcesManager* sharedResourcesManager();
        
        std::string getDefaultPath();
        bool isExist(cocos2d::CCString fullPath);
        
        // zip解凍
        bool unZip(void* data, unsigned long size);
        bool unZip(const char* path);
        
        /**
        * \brief ここに追加すべきかどうか分からないが。。。\n
        * 相手のダウンロードしたアバターのテクスチャーは使い回すので、どこかに保持しないといけない。
        * reference counterは2の状態。
        *
        * \return アバターのテクスチャー
        */
        cocos2d::CCTexture2D* getPvpRemoteAvatarTexture(Bool has_a_bg=true);
        /**
        * \brief ここに追加すべきかどうか分からないが。。。\n
        * 相手のダウンロードしたアバターのテクスチャーは使い回すので、どこかに保持しないといけない。
        * 内部でreference counterを1増やします。
        *
        * \param texture 保持するアバターのテクスチャー、NULL指定で解放します。
        */
        void setPvpRemoteAvatarTexture(const cocos2d::CCTexture2D* texture, Bool has_a_bg=true);
        /**
        * \brief ここに追加すべきかどうか分からないが。。。\n
        * デフォルトのアバターテクスチャー
        * 特にretain/releaseはせず、reference counterは1の状態。
        *
        * \return アバターのデフォルトテクスチャー
        */
        cocos2d::CCTexture2D* getPvpDefaultAvatarTexture(Bool has_a_bg=true);
        /**
        * \brief ここに追加すべきかどうか分からないが。。。\n
        * 相手のダウンロードしたアバターのテクスチャーは使い回すので、どこかに保持しないといけない。
        * 内部でreference counterを1増やします。
        *
        * \param texture 保持するデフォルトアバターのテクスチャー、NULL指定で解放します。
        */
        void setPvpDefaultAvatarTexture(const cocos2d::CCTexture2D* texture, Bool has_a_bg=true);
        
        
        // イメージデータ取得
        cocos2d::CCImage* getImage();
        
        // 新・イメージデータ取得
        cocos2d::CCTexture2D *getDBTexture(std::string imagePath, bool cacheEnable = true);
                
        // texturePackermから読み込む。（plistはファイル名と一緒）
        cocos2d::CCSpriteFrame* getTextureFromTexturePacker(const std::string& plistFileName, const std::string& frameKeyName, const std::string& type = ".png");
        cocos2d::CCTexture2D* getTextureFromTexturePackerNoChache(std::string imageName, std::string frameKeyName, std::string type = ".png");
        
        // フルパスからファイル名を取得する
        std::string getFilename(const char* fullpath);
        
        // 
        bool saveFile(std::vector<char> *buffer, const std::string& fileName);
		bool saveFile(void *buffer, unsigned long size, const std::string& fileName);
        void deleteFile(std::string fileName);
        void deleteFileLibrary(std::string fileName);
        bool executeUpdateMasterData(cocos2d::CCDictionary *dic);
        
    private:
        
        /**
        * \brief ここにいれるべきかどうかわからないが、とにかく。。。
        */
        cocos2d::CCTexture2D* pvp_remote_avatar_texture_;
        cocos2d::CCTexture2D* pvp_remote_avatar_texture_no_bg_;
        /**
        * \brief アバターのデフォルトテクスチャー
        */
        cocos2d::CCTexture2D* pvp_default_avatar_texture_;
        cocos2d::CCTexture2D* pvp_default_avatar_texture_no_bg_;
        
        /**
         * Singleton
         */
        ResourcesManager();
        static ResourcesManager* spResourcesManager_;
        
#ifdef ANDROID_CHAOS
    private:
        std::string defaultPath_;
#endif
    };

}}

#endif /* defined(__chaos__ResourcesManager__) */
