//
//  downloader.cpp
//  chaos
//
//  ダウンローダー
//
//  Created by 何 利強 on 2016/09/06.
//
//

#include "ResourcesManager/downloader.h"
#include "ResourcesManager/unziper.h"

#include "application/joker_application.h"
#include "parameter/parameter_manager.h"

namespace Chaos {
namespace ResourcesManager {

/**
 * \brief 都度DLで、リソースファイルを書き込む
 */
static size_t writeDlResData(void *ptr, size_t size, size_t nmemb,
                             void *stream) {
    std::vector<char> *recvBuffer = (std::vector<char> *)stream;
    size_t sizes = size * nmemb;
    recvBuffer->insert(recvBuffer->end(), (char *)ptr, (char *)ptr + sizes);
    return sizes;
}

/**
 * \brief 都度DLで、リソースファイルのプログレス
 */
static int dlResProgressFunc(void *ptr, double totalToDownload,
                             double nowDownloaded, double totalToUpLoad,
                             double nowUpLoaded) {
    if (totalToDownload == 0) {
        return 0;
    }
    *reinterpret_cast<F32 *>(ptr) = F32(nowDownloaded / totalToDownload);
    return 0;
}
/**
 * @brief ダウンロードを作成する
 * @param[in] iUnziper 解凍者
 * @param[in] iDownloaderNo ダウンローダーNo
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iIsBackgroundDownload バックグラウンドDLフラグ
 */
Downloader *Downloader::create(Unziper *iUnziper, const S32 iDownloaderNo,
                               const S32 iDownloadIndex,
                               const Bool iIsBackgroundDownload) {
    Downloader *pRet = new Downloader();
    if (pRet) {
        pRet->SetUnziper(iUnziper);
        pRet->SetDownloadInfo(iDownloaderNo, iDownloadIndex,
                              iIsBackgroundDownload);
        return pRet;
    } else {
        CC_SAFE_DELETE(pRet);
        pRet = NULL;
    }
    return NULL;
}

Downloader::Downloader()
    : download_parameter_(NULL),
      isCanceled_(false),
      state_(kTDownloadStateIdle),
      isBackgroundDownload_(false),
      downloader_no_(-1) {
    // ダウンロードパラメーターを取得する
    JOKER::ParameterManager *pm =
        JOKER::JokerApplication::GetInstance()->GetParameterManager();
    this->download_parameter_ = pm->GetDownloadParameter();
}
Downloader::~Downloader() {
    // 解放する前に、無限ループでスレッドをチェックする
    while (true) {
        if (this->isStoped()) {
            break;
        }

        // 待機中の場合
        if (this->isPausing()) {
            this->Continue();
        }

        //usleep(1000);
    }
    this->workCurl_.destory();
}

/**
 * @brief ダウンロードを開始する
 */
const void Downloader::StartDownload() {
    JOKER_DEBUG("\n[Debug:C I/A][%d/%d]Downloader::StartDownload",
                this->download_index_, this->downloader_no_);

    CC_ASSERT(!workCurl_.thread_);
    workCurl_.unit_progress_ = 0.0f;
    pthread_create(&workCurl_.thread_, NULL, Download, this);
    pthread_detach(workCurl_.thread_);
}

/**
 * @brief 停止してるかどうかのチェック
 * @return 停止フラグ
 */
const Bool Downloader::isStoped() {
    // 失敗の場合
    if (this->isFailed()) {
        return true;
    }

    // 完了ではない場合
    if (kTDownloadStateCompleted > this->state_) {
        return false;
    }

    // スレッドでチェック
    if (this->workCurl_.thread_) {
        return false;
    }
    return true;
}

/**
 * @brief ダウンロードを一時停止にする
 */
const void Downloader::Pause() {
    // ダウンロードステートを設定する
    this->state_ = kTDownloadStatePausing;
}

/**
 * @brief ダウンロードを続く
 */
const void Downloader::Continue() {
    pthread_cond_signal(&this->workCurl_.sleep_condition_);
}

/**
 * @brief ダウンロードをリセットする
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iIsBackgroundDownload バックグラウンドDLフラグ
 */
const void Downloader::Reset(const S32 iDownloadIndex,
                             const Bool iIsBackgroundDownload) {
    this->SetDownloadInfo(this->downloader_no_, iDownloadIndex,
                          iIsBackgroundDownload);

    // ダウンロードステートを設定する
    //    this->state_ = kTDownloadStateIdle;
}

/**
 * @brief リトライできるかどうかの判定
 * @return リトライできるかどうかのフラグ
 */
const Bool Downloader::isRetryAble() {
    // 接続失敗（リトライができる）の場合、または、
    // タイムアウト（リトライができる）の場合、または、
    // エラー（リトライができる）の場合のみ、リトライできる
    if ((Downloader::kTDownloadStateConnectFailed == this->state_) ||
        (Downloader::kTDownloadStateTimeOut == this->state_) ||
        (Downloader::kTDownloadStateError == this->state_)) {
        return true;
    }

    return false;
}

/**
 * @brief 失敗したかどうかの判定
 * @return 失敗したかどうかのフラグ
 */
const Bool Downloader::isFailed() {
    // 接続失敗（リトライができる）の場合、または、
    // タイムアウト（リトライができる）の場合、または、
    // エラー（リトライができる）の場合のみ、リトライできる
    if ((Downloader::kTDownloadStateConnectFailed == this->state_) ||
        (Downloader::kTDownloadStateTimeOut == this->state_) ||
        (Downloader::kTDownloadStateError == this->state_) ||
        (Downloader::kTDownloadStateException == this->state_)) {
        return true;
    }

    return false;
}

/**
 * @brief 解凍者を設定する
 * @param[in] iUnziper 解凍者
 */
const void Downloader::SetUnziper(Unziper *iUnziper) {
    if (!iUnziper) {
        return;
    }
    this->unziper_ = iUnziper;
}

/**
 * @brief ダウンロードをリトライする
 */
const void Downloader::Retry() {
    // リトライできない場合、スキップする
    if (!this->isRetryAble()) {
        return;
    }

    // リトライ
    this->state_ = Downloader::kTDownloadStateRetry;

    // リトライにするため、ダウンロードシングルを送る
    pthread_cond_signal(&this->workCurl_.sleep_condition_);
}

/**
 * @brief ダウンロードをキャンセルする
 */
const void Downloader::Cancel() {
    this->isCanceled_ = true;

    // リトライを待つため、終わらせるため、シングルを送る
    if (this->isRetryAble() || this->isPausing()) {
        pthread_cond_signal(&this->workCurl_.sleep_condition_);
    }
};

/**
 * @brief CURLのオプションを初期化にする
 * @param[in] iWriteBuff 書き込む用バファー
 */
CURL *Downloader::InitCurlOption(std::vector<char> *iWriteBuff) {
    CURL *pCurl = curl_easy_init();
    if (!pCurl) {
        NULL;
    }

    // Curlの各オプション設定
    curl_easy_setopt(pCurl, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(pCurl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(pCurl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(pCurl, CURLOPT_DNS_CACHE_TIMEOUT, 60);
    curl_easy_setopt(pCurl, CURLOPT_CONNECTTIMEOUT, 10);
    curl_easy_setopt(pCurl, CURLOPT_TIMEOUT, 60);
    curl_easy_setopt(pCurl, CURLOPT_WRITEFUNCTION, writeDlResData);
    curl_easy_setopt(pCurl, CURLOPT_WRITEDATA, &(*iWriteBuff));
    curl_easy_setopt(pCurl, CURLOPT_NOPROGRESS, false);
    curl_easy_setopt(pCurl, CURLOPT_PROGRESSDATA,
                     this->workCurl_.unit_progress_);
    curl_easy_setopt(pCurl, CURLOPT_FOLLOWLOCATION, true);
    curl_easy_setopt(pCurl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_WHATEVER);

    return pCurl;
}

/**
 * \brief ファイルをダウンロードする
 * \param[in] iDownloader ダウンローダー
 */
void *Downloader::Download(void *iDownloader) {
    Downloader *self = (Downloader *)iDownloader;
    if (self == NULL) {
        self->workCurl_.thread_ = NULL;
        return NULL;
    }

    if (!self->download_parameter_) {
        JOKER_DEBUG("\n[Debug:C I/A][%d/%d]Downloader::Download::Download Parameter is null!!!",
                    self->download_index_, self->downloader_no_);
        self->workCurl_.thread_ = NULL;
        return NULL;
    }

    // CURLのオプションを初期化にする
    std::vector<char> writeBuf;
    CURL *pCurl = self->InitCurlOption(&writeBuf);
    if (!pCurl) {
        JOKER_DEBUG("\n[Debug:C I/A][%d/%d]Downloader::Download::Curl Init Failed!!!",
                    self->download_index_, self->downloader_no_);
        self->workCurl_.thread_ = NULL;
        return NULL;
    }

    // ダウンロード詳細を取得する
    JOKER::TDownloadDetailInfo *downloadDetail =
        self->download_parameter_->getDownloadDetail(self->download_index_);
    if (!downloadDetail) {
        
        JOKER_DEBUG("\n[Debug:C I/A][%d/%d]Downloader::Download::No Download Detail!!!",
                    self->download_index_, self->downloader_no_);
        
        // リソースターゲットズをループして、ダウンロードを行う
        curl_easy_cleanup(pCurl);
        self->workCurl_.thread_ = NULL;
        return NULL;
    }

    // キャンセルされない場合、ダウンロードを続行する
    JOKER::TResourceInfo *pCurrentDownloadTarget = NULL;
    while ((!self->isCanceled()) &&
           (pCurrentDownloadTarget ||
            (!downloadDetail->download_targets_.Empty(
                (pCurrentDownloadTarget ? true : false))))) {
        if (!pCurrentDownloadTarget) {
            pCurrentDownloadTarget =
                downloadDetail->download_targets_.Pop(false);
        }

        // 例外（リトライができない）の場合、終了する
        if (Downloader::kTDownloadStateException == self->state_) {
            JOKER_DEBUG("\n[Debug:C I/A][%d/%d]Downloader::Download::Exception!!!!!",
                        self->download_index_, self->downloader_no_);
            break;
        }

        // ターゲットがない場合、ダウンロード終了
        if (!pCurrentDownloadTarget) {
            JOKER_DEBUG("\n[Debug:C I/A][%d/%d]Downloader::Download::Download Target is null!!!!!",
                        self->download_index_, self->downloader_no_);
            break;
        }

        // 一時停止の場合、待機
        if (self->isPausing()) {
            // ステートの設定
            pthread_cond_wait(&self->workCurl_.sleep_condition_,
                              &self->workCurl_.sleep_mutex_);
        }

        // 全件既にダウンロードされた場合
        if (self->download_parameter_->isAllTargetsDownloaded(
                self->getDownloadIndex(), self->isBackgroundDownload_)) {
            JOKER_DEBUG("\n[Debug:C I/A][%d/%d]Downloader::Download::Download All Completed!!!!!",
                        self->download_index_, self->downloader_no_);
            break;
        }

        // 該当する、リソースは、既にダウンロードされた場合、スキップする
        if (pCurrentDownloadTarget->downloaded_) {
            pCurrentDownloadTarget = NULL;
            continue;
        }

        // ダウンローダーする
        self->state_ =
            self->DownloadByTargetInfo(pCurl, pCurrentDownloadTarget, writeBuf);

        // 完了
        if (Downloader::kTDownloadStateCompleted == self->state_) {
            // 該当するリソース情報を設定する
            self->download_parameter_->updateResourceInfoWhenDownloaded(
                self->downloader_no_, self->getDownloadIndex(),
                pCurrentDownloadTarget->resourceId_);

            // ダウンロードが完了したので、解凍シングルを送る
            if (self->unziper_) {
                self->unziper_->Continue();
            }

            // 全ユーザーが、サーバーに頻繁にダウンロードするのを回避するため、リソースファイル毎に0.1sを待つ
            usleep(100);

        } else if ((Downloader::kTDownloadStateConnectFailed == self->state_) ||
                   (Downloader::kTDownloadStateTimeOut == self->state_) ||
                   (Downloader::kTDownloadStateError == self->state_)) {

            // リトライのシングルをくるまで、待機
            pthread_cond_wait(&self->workCurl_.sleep_condition_,
                              &self->workCurl_.sleep_mutex_);
            continue;

        } else {
            break;
        }

        pCurrentDownloadTarget = NULL;
    }

    // リソースターゲットズをループして、ダウンロードを行う
    curl_easy_cleanup(pCurl);

    self->workCurl_.thread_ = NULL;
    pthread_mutex_destroy(&self->workCurl_.sleep_mutex_);
    pthread_cond_destroy(&self->workCurl_.sleep_condition_);

    // ステートを設定する
    self->state_ = kTDownloadStateCompleted;

    JOKER_DEBUG("\n[Debug:C I/A][%d/%d]Downloader::Download::Completed -> End",
                self->download_index_, self->downloader_no_);

    return 0;
}

/**
 * \brief ターゲットをダウンロードする
 * \param[in] iCurl CURL
 * \param[in] iDownloadTarget ダウンローダーターゲット情報
 * \param[in] iWriteBuffer 書き込む用バッファー
 */
const Downloader::TDownloadState Downloader::DownloadByTargetInfo(
    CURL *iCurl, JOKER::TResourceInfo *iDownloadTarget,
    std::vector<char> &iWriteBuffer) {
    if (!iCurl) {
        return Downloader::kTDownloadStateException;
    }
    if (!iDownloadTarget) {
        return Downloader::kTDownloadStateException;
    }

    // 接続中
    this->state_ = Downloader::kTDownloadStateConnecting;

    curl_easy_setopt(iCurl, CURLOPT_URL, iDownloadTarget->downloadUrl_.c_str());
    this->workCurl_.downloading_zip_filename_ =
        strrchr(iDownloadTarget->downloadUrl_.c_str(), '/') + 1;

    JOKER_DEBUG(
        "\n[Debug:C "
        "I/A][DlResource][%d/"
        "%d]Downloader::DownloadByTargetInfo::[Start] %s\n",
        this->download_index_, this->downloader_no_,
        this->workCurl_.downloading_zip_filename_);

    long response_code = -1;
    CURLcode result = curl_easy_perform(iCurl);
    if (result == CURLE_OK) {
        result =
            curl_easy_getinfo(iCurl, CURLINFO_RESPONSE_CODE, &response_code);
    }

    // ダウンロードが既に完了された場合
    if (iDownloadTarget->downloaded_) {
        // 書き込み用のバッファーをクリアする
        iWriteBuffer.clear();

        return Downloader::kTDownloadStateCompleted;
    }

    // ダウンロード中
    this->state_ = kTDownloadStateDownloading;

    if (result == CURLE_OK && response_code == 200) {
        iDownloadTarget->data_ = malloc(iWriteBuffer.size());
        iDownloadTarget->dataSize_ = iWriteBuffer.size();
        memcpy(iDownloadTarget->data_, &iWriteBuffer[0], iWriteBuffer.size());
        iWriteBuffer.clear();

        // ダウンロードファイル数をカウントする
        this->workCurl_.unit_progress_ = 0;

    }
    // エラーの場合
    else {
        // 該当するリソース情報をクリアする
        JOKER_DEBUG(
            "\n[Debug:C "
            "I/A][%d/%d][DlResource]Downloader::DownloadByTargetInfo::Curl "
            "Error[ResultCode:%d] : %s\n",
            this->download_index_, this->downloader_no_, (U32)result,
            curl_easy_strerror(result));
        iWriteBuffer.clear();

        // 接続失敗
        if (CURLE_COULDNT_CONNECT == result) {
            return Downloader::kTDownloadStateConnectFailed;
        } else if ((CURLE_FTP_ACCEPT_TIMEOUT == result) ||
                   (CURLE_OPERATION_TIMEDOUT == result)) {
            return Downloader::kTDownloadStateTimeOut;
        } else if ((CURLE_COULDNT_RESOLVE_HOST == result)) {
            return Downloader::kTDownloadStateError;
        }

        return Downloader::kTDownloadStateException;
    }

    return Downloader::kTDownloadStateCompleted;
}
}
}