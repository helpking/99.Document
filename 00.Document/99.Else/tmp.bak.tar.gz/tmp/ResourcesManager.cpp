//
//  ResourcesManager.cpp
//  chaos
//
//  Created by B02892 on 13/04/10.
//
//

#include "ResourcesManager.h"

#include "NEED_FOR_REFACTOR/Util.h"
#include "ScopedClock.h"
#include "support/zip_support/unzip.h"
#include <regex.h>
#include <string>
#include <fstream>
#include "binary_ioapi.h"

#ifdef ANDROID_CHAOS
#include "ApplibotAndroidJni.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>

#include "DownloadResourcesManager.h"

using namespace cocos2d;
using namespace extension;
using namespace std;


namespace Chaos {
namespace ResourcesManager {
    ResourcesManager* ResourcesManager::spResourcesManager_ = 0;

    /**
     * \~english default constructor
     * \~japanese デフォルトコンストラクタ
     *  \brief デフォルトコンストラクタ
     */
    ResourcesManager::ResourcesManager()
    : pvp_remote_avatar_texture_(NULL)
    , pvp_default_avatar_texture_(NULL)
    , pvp_default_avatar_texture_no_bg_(NULL)
    , pvp_remote_avatar_texture_no_bg_(NULL)
    {
        spResourcesManager_ = NULL;
        
#ifdef ANDROID_CHAOS
        defaultPath_ = CCFileUtils::sharedFileUtils()->getWritablePath();
#else
        if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS) {
            // TODO:後で直す
            {
                string ResourecePath = this->getDefaultPath() + "sound";
                CCLog("Path Create : %s", ResourecePath.c_str());
                mkpath_np(ResourecePath.c_str(), 0755);
            }
            {
                string ResourecePath = this->getDefaultPath() + "sound/bgm";
                CCLog("Path Create : %s", ResourecePath.c_str());
                mkpath_np(ResourecePath.c_str(), 0755);
            }
            {
                string ResourecePath = this->getDefaultPath() + "sound/jingle";
                CCLog("Path Create : %s", ResourecePath.c_str());
                mkpath_np(ResourecePath.c_str(), 0755);
            }
            {
                string ResourecePath = this->getDefaultPath() + "sound/se";
                CCLog("Path Create : %s", ResourecePath.c_str());
                mkpath_np(ResourecePath.c_str(), 0755);
            }
        }
        //TODO OS
#endif
    }

    /**
     * \~english destructor
     * \~japanese デストラクタ
     *  \brief デストラクタ
     */
    ResourcesManager::~ResourcesManager()
    {
        spResourcesManager_ = NULL;
        
        CC_SAFE_RELEASE_NULL(pvp_default_avatar_texture_);
        CC_SAFE_RELEASE_NULL(pvp_default_avatar_texture_no_bg_);
        CC_SAFE_RELEASE_NULL(pvp_remote_avatar_texture_);
        CC_SAFE_RELEASE_NULL(pvp_remote_avatar_texture_no_bg_);
    }

    /**
     * \~english
     * \~japanese
     *  \brief
     */
    ResourcesManager* ResourcesManager::sharedResourcesManager()
    {
        //CCLOG("sharedResourcesManager");

        if (! spResourcesManager_)
        {
            spResourcesManager_ = new ResourcesManager();
        }

        return spResourcesManager_;
    }

    /**
     * \~english return default path
     * \~japanese デフォルトのパスを返却
     *  \brief デフォルトのパスを返却
     */
    string ResourcesManager::getDefaultPath()
    {
        string path;
        if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS) {
            path = CCFileUtils::sharedFileUtils()->getWritablePath() + "Caches/";
        }
        else if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID){
#ifdef ANDROID_CHAOS
            return defaultPath_;// + "Caches/";
#else
            path = CCFileUtils::sharedFileUtils()->getWritablePath();
#endif
        }

        return path;
    }

    /**
     * \~english check file existing
     * \~japanese ファイルの存在確認
     *  \brief ファイルの存在確認
     */
    bool ResourcesManager::isExist(cocos2d::CCString fullPath)
    {
        bool isExist = false;
        FILE *fp = fopen(fullPath.getCString(), "rb");
        if (fp != NULL) {
            isExist = true;
            fclose(fp);
        }

        return isExist;
    }

    /**
     * \~english save file
     * \~japanese ファイルの保存
     *  \brief ファイルの保存
     */
    bool ResourcesManager::saveFile(void *buffer, unsigned long size, const std::string& fileName) {

        bool isSuccess = false;

        // 圧縮ファイルだったら解凍
        if (fileName.find(".zip") != std::string::npos) {
            isSuccess = this->unZip(buffer, size);
            JOKER_DEBUG("\n[Debug:C I/A][DLResource]ResourcesManager::saveFile::ZipFile -> %s\n", fileName.c_str());
        } else {
            // 保存パス
            const string filePath = this->getDefaultPath() + fileName;
            
//            JOKER_DEBUG("[Debug:C I/A][DLResource]ResourcesManager::saveFile::unZipFile:: -> %s\n", filePath.c_str());

            // ファイルの保存
            int file = open( filePath.c_str(), O_CREAT | O_WRONLY | O_TRUNC, S_IRWXU | S_IRWXG );
            isSuccess = ( write(file, buffer, size) == size );
            close( file );
        }

        if( !isSuccess ) {
            CCLOG("");
        }

        return isSuccess;
    }

    /**
     * \~english
     * \~japanese
     *  \brief
     */
    bool ResourcesManager::saveFile(vector<char> *buffer, const std::string& fileName){
        return saveFile( (void*)&buffer->at(0), buffer->size(), fileName );
    }

    /**
     * \~english delete files (Cache)
     * \~japanese ファイルの削除(Cache)
     *  \brief ファイルの削除(Cache)
     */
    void ResourcesManager::deleteFile(std::string fileName) {
        string filePath = this->getDefaultPath() + fileName;
        CCLog("delete path %s",filePath.c_str());
        if (remove(filePath.c_str())) {
            CCLog("deleteFile Error.");
        } else {
            CCLog("%s deleted.",fileName.c_str());
        }
    }

    /**
     * \~english delete files (Library)
     * \~japanese ファイルの削除(Library)
     *  \brief ファイルの削除(Library)
     */
    void ResourcesManager::deleteFileLibrary(std::string fileName) {
        string filePath = CCFileUtils::sharedFileUtils()->getWritablePath() + fileName;
        CCLog("delete path %s",filePath.c_str());
        if (remove(filePath.c_str())) {
            CCLog("deleteFile Error.");
        } else {
            CCLog("%s deleted.",fileName.c_str());
        }
    }

    /**
     * \~english unzip
     * \~japanese zipの解凍
     *  \brief zipの解凍
     */
    bool ResourcesManager::unZip(void* data, unsigned long size)
    {
        BINARY binary;
        binary.data_ = (unsigned char*)data;
        binary.size_ = size;
        binary.offset_ = 0;

        zlib_filefunc_def def;
        fill_bopen_filefunc( &def, &binary );
		
        bool isSuccess = false;
        unsigned long beforeSize=0;
        char* pBuffer=0;

        unzFile unzFile_ = unzOpen2("", &def);
        if (unzGoToFirstFile(unzFile_) != UNZ_OK) {
            unzClose( unzFile_ );
            CC_ASSERT(0);
            return false;
        }
		
        while (true) {
            unz_file_info64 fileInfo;
            char fileName[PATH_MAX];
            if (unzGetCurrentFileInfo64(unzFile_, &fileInfo, fileName, PATH_MAX, NULL, 0, NULL, 0) != UNZ_OK) {
                CCLog("unzGetCurrentFileInfo64 != UNZ_OK");
                break;
            }
//            CCLog("UnZipFileName : %s", fileName);
            if (unzLocateFile(unzFile_, fileName, 0) != UNZ_OK) {
                CCLog("unzLocateFile != UNZ_OK");
                break;
            }

            if (unzOpenCurrentFile(unzFile_) != UNZ_OK) {
                CCLog("unzOpenCurrentFile != UNZ_OK");
                break;
            }

            // ファイル保存先を Caches/XXXX/hoge.png　になるように修正する
            string rename(fileName);

            // 正常なファイルか検証
            bool isValidTarget = true;

            if(rename.find("MACOSX") != string::npos) {
                isValidTarget = false;
                CCLOG("MACOSX had found! [%s]", rename.c_str());
            } else if(rename.find("Thumbs.db") != string::npos) {
                isValidTarget = false;
                CCLOG("Thumbs.db had found! [%s]", rename.c_str());
            } else if(Chaos::Util::Util::hasMultiByteCharacter(rename.c_str())) {
                isValidTarget = false;
                CCLOG("Multibyte character had found! [%s]", rename.c_str());
            }

            if( isValidTarget ) {
                rename.erase(0, rename.find_first_of("/") + 1);

                // データの展開
                {                    
                    if (fileInfo.uncompressed_size == 0) {
                        // Folderを作成
                        string ResourecePath = this->getDefaultPath() + rename;
//                        CCLog("Path Create : %s", ResourecePath.c_str());
                        
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
                        mkpath_np(ResourecePath.c_str(), 0755);
#else
                        mkdir(ResourecePath.c_str(),0770);
#endif
                    } else {
                        //CCLog("is File on Size %ld", fileInfo.uncompressed_size);
                        // 鬼KARI対処
                        string ResourecePath = this->getDefaultPath();
                        Chaos::Util::Util::createFilepathMkdir(ResourecePath,rename);

                        // adk: 以前、生成したメモリの方が大きければそのまま使う。
                        if (beforeSize<fileInfo.uncompressed_size)
                        {
                            delete[] pBuffer;
                            pBuffer = new char[fileInfo.uncompressed_size];
                            beforeSize = fileInfo.uncompressed_size;
                        }

                        unzReadCurrentFile(unzFile_, pBuffer, fileInfo.uncompressed_size);
                        if( !saveFile( pBuffer, fileInfo.uncompressed_size, rename ) ){
                            break;
                        }
                    }

                    unzCloseCurrentFile(unzFile_);
                }
            }

            int error = unzGoToNextFile(unzFile_);
            if (error == UNZ_END_OF_LIST_OF_FILE) {
                // 最後のファイルまでいった
//                CCLog("UNZ_END_OF_LIST_OF_FILE");
                isSuccess = true;
                break;
            }
            if (error != UNZ_OK) {
                CCLog("error != UNZ_OK");
                break;
            }
        }
        delete[] pBuffer;
        unzClose( unzFile_ );
        return isSuccess;
    }

    /**
     * \~english
     * \~japanese
     *  \brief
     */
    bool ResourcesManager::unZip(const char* path)
    {
        std::ifstream file(path, std::ios::binary);
        if( file.is_open() ){
            file.seekg(0, std::ios::end);
            const std::streampos filesize = file.tellg();
            file.seekg(0, std::ios::beg);

            char* buffer = new char[filesize];
            file.read(buffer, filesize);
            const bool result = unZip(buffer, filesize);
            delete[] buffer;

            return result;
        }
        return false;
    }

    /**
     * \~english
     * \~japanese
     *  \brief
     */
    cocos2d::CCTexture2D* ResourcesManager::getPvpRemoteAvatarTexture(Bool has_a_bg)
    {
        return has_a_bg?pvp_remote_avatar_texture_:pvp_remote_avatar_texture_no_bg_;
    }
    void ResourcesManager::setPvpRemoteAvatarTexture(const cocos2d::CCTexture2D* texture, Bool has_a_bg)
    {
        if (has_a_bg)
        {
            if (pvp_remote_avatar_texture_)
            {
                CCTextureCache::sharedTextureCache()->removeTexture(pvp_remote_avatar_texture_);
                pvp_remote_avatar_texture_->release(), pvp_remote_avatar_texture_=0;
            }
        } else {
            if (pvp_remote_avatar_texture_no_bg_)
            {
                CCTextureCache::sharedTextureCache()->removeTexture(pvp_remote_avatar_texture_no_bg_);
                pvp_remote_avatar_texture_no_bg_->release(), pvp_remote_avatar_texture_no_bg_=0;
            }
        }
        if (texture==NULL)
        {
            return ;
        }

        if (has_a_bg)
        {
            
            pvp_remote_avatar_texture_=(cocos2d::CCTexture2D*)texture;
            pvp_remote_avatar_texture_->retain();
            pvp_remote_avatar_texture_->set_object_name("select real");
        } else {
            pvp_remote_avatar_texture_no_bg_=(cocos2d::CCTexture2D*)texture;
            pvp_remote_avatar_texture_no_bg_->retain();
            pvp_remote_avatar_texture_no_bg_->set_object_name("select real no bg");
        }
    }
#define DEFAULT_AVATAR_IMAGE_PATH ("avatarEdit/avatar_default_dummy.jpg")
#define DEFAULT_AVATAR_NO_BG_IMAGE_PATH ("avatarEdit/avatar_default_no_bg.png")
    /**
     * \~english
     * \~japanese
     *  \brief
     */
    cocos2d::CCTexture2D* ResourcesManager::getPvpDefaultAvatarTexture(Bool has_a_bg/*=true*/)
    {
        const Char* default_image_path = ((has_a_bg==true)?DEFAULT_AVATAR_IMAGE_PATH:DEFAULT_AVATAR_NO_BG_IMAGE_PATH);
        CCTexture2D* texture = ((has_a_bg==true)?pvp_default_avatar_texture_:pvp_default_avatar_texture_no_bg_);
        
        JOKER_DEBUG("ResourcesManager::getPvpDefaultAvatarTexture(%d), %s\n", has_a_bg, default_image_path);
        if (texture==NULL)
        {
            texture = CCTextureCache::sharedTextureCache()->addImage(default_image_path);
            JOKER_ASSERT(texture);
            texture->retain();
            
            if (has_a_bg==true)
            {
                pvp_default_avatar_texture_ = texture;
                pvp_default_avatar_texture_->set_object_name("dummy avatar_");
            } else {
                pvp_default_avatar_texture_no_bg_ = texture;
                pvp_default_avatar_texture_no_bg_->set_object_name("dummy avatar_ no bg");
            }
        }
        return has_a_bg? pvp_default_avatar_texture_:pvp_default_avatar_texture_no_bg_ ;
    }

    /**
     * \~english
     * \~japanese
     *  \brief
     */
    void ResourcesManager::setPvpDefaultAvatarTexture(const cocos2d::CCTexture2D* texture, Bool has_a_bg)
    {
        if (texture==NULL)
        {
            if (has_a_bg==true)
            {
                if (pvp_default_avatar_texture_)
                {
                    pvp_default_avatar_texture_->release(), pvp_default_avatar_texture_=NULL;
                }
            } else {
                if (pvp_default_avatar_texture_)
                {
                    pvp_default_avatar_texture_no_bg_->release(), pvp_default_avatar_texture_no_bg_=NULL;
                }
            }
            return ;
        }

        if (has_a_bg)
        {
            if (pvp_default_avatar_texture_)
            {
                pvp_default_avatar_texture_->release();
            }
            pvp_default_avatar_texture_ = (cocos2d::CCTexture2D*)texture;
            pvp_default_avatar_texture_->retain();
        } else {
            if (pvp_default_avatar_texture_no_bg_)
            {
                pvp_default_avatar_texture_no_bg_->release();
            }
            pvp_default_avatar_texture_no_bg_= (cocos2d::CCTexture2D*)texture;
            pvp_default_avatar_texture_no_bg_->retain();
        }
    }

    /**
     * \~english create texture by new file
     * \~japanese 新・ファイルからテクスチャを作成
     *  \brief 新・ファイルからテクスチャを作成
     */
    CCTexture2D *ResourcesManager::getDBTexture(std::string imagePath, bool cacheEnable)
    {
        CCTexture2D* result = CCTextureCache::sharedTextureCache()->addImage( imagePath.c_str() );
        
        // ダミー素材
        if( !result ){
            result = CCTextureCache::sharedTextureCache()->addImage( DUMMY_IMAGE_NAME );
            CCLOG("Using dummy [%s]", imagePath.c_str());
        }

        CC_ASSERT(result);
        return result;
    }

    /**
     * \~english create texture by TexturePacker of file
     * \~japanese ファイルのTexturePackerからテクスチャを作成
     *  \brief ファイルのTexturePackerからテクスチャを作成
     */
    CCSpriteFrame* ResourcesManager::getTextureFromTexturePacker(const std::string& plistFileName, const std::string& frameKeyName, const std::string& type)
    {
        // png指定等で送ってくる不届き者がいるので、強制変換
        const std::string::size_type pos = plistFileName.find_last_of(".");
        const std::string _plistFileName( plistFileName.substr(0, pos) + ".plist" );
        
        CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile( _plistFileName.c_str() );
        
        const std::string frameName( frameKeyName + type );
        CCSpriteFrame* result = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName( frameName.c_str() );
        
        // ダミー素材
        if( !result ){
            CCTexture2D* texture = CCTextureCache::sharedTextureCache()->addImage(DUMMY_IMAGE_NAME);
            CCSpriteFrame* dummy = CCSpriteFrame::createWithTexture(texture, CCRect(0, 0, 100, 100));
            CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFrame( dummy, frameName.c_str() );
            result = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName( frameName.c_str() );
            CCLOG("Using dummy [%s][%s]", _plistFileName.c_str(), frameName.c_str());
        }

        CC_ASSERT(result);
        return result;
    }

    /**
     * \~english create texture by TexturePacker of file. the function doesn't see cache.
     * \~japanese ファイルのTexturePackerからテクスチャを作成。この関数はキャッシュを見に行かない。
     *  \brief ファイルのTexturePackerからテクスチャを作成。この関数はキャッシュを見に行かない。
     */
    CCTexture2D* ResourcesManager::getTextureFromTexturePackerNoChache(std::string imageName, std::string frameKeyName, std::string type)
    {
        // plistパスを取得
        std::string::size_type endPos = imageName.find_last_of(".");
        std::string plistPath = imageName.substr(0, endPos);
        plistPath += ".plist";

        // APPのパス
        std::string plistAPPPath = CCFileUtils::sharedFileUtils()->fullPathForFilename(plistPath.c_str());
        // キャッシュのパス
        plistPath = this->getDefaultPath() + plistPath;
        std::string fullImagePath = this->getDefaultPath() + imageName;

        // 指定のフレーム名
        std::string frameName =  frameKeyName + type;
        CCTexture2D *texture = CCTextureCache::sharedTextureCache()->addImage(fullImagePath.c_str());
        if (texture == NULL)
        {
            CCImage* image = NULL;
            // imagePath は card/hogehoge.png で指定されていて
            // 読み込む際は ~/Library/Caches/card/hogehoge.png になる
            if (imageName.length() != 0) {
                // ローカルストレージ利用
                CCLOG("fullPath %s",fullImagePath.c_str());
 
                // ファイルの有無確認
                if (this->isExist(fullImagePath)) {
                    image = new CCImage();
                    if (std::string::npos != fullImagePath.find(".jpg") || std::string::npos != fullImagePath.find(".jpeg"))
                    {
                        image->initWithImageFile(fullImagePath.c_str() ,CCImage::kFmtJpg);
                    } else {
                        image->initWithImageFile(fullImagePath.c_str());
                    }

                    texture = CCTextureCache::sharedTextureCache()->addUIImage(image, imageName.c_str());
                    image->release();
                } else {
                    CCLOG("指定の素材(%s)が見つかりません。", fullImagePath.c_str());
                }
            }

            if(texture == NULL) {
                CCLOG("アプリ素材から(%s)を取得します。", imageName.c_str());

                //組み込んであるデータから取得
                while (imageName.find("/") != string::npos) {
                    imageName.erase(0, imageName.find_first_of("/") + 1);
                }
                CCLog("localFile %s",imageName.c_str());
                texture = CCTextureCache::sharedTextureCache()->addImage(imageName.c_str());
            }

            if (texture == NULL)
            {
                CCLOG("素材(%s)が見つかりませんでした。", imageName.c_str());
                CCLOG("spriteSheet none!!!: %s", imageName.c_str());
                // キャッシュにも組み込みにもなかった→ダミー画像
                texture = CCTextureCache::sharedTextureCache()->addImage(DUMMY_IMAGE_NAME);
            }
        }
        return texture;
    }

    /**
     * \~english get file name by fullpath
     * \~japanese フルパスからファイル名を取得する
     *  \brief フルパスからファイル名を取得する
     */
    std::string ResourcesManager::getFilename(const char* fullpath)
    {
        //CCLOG("getFilename before: %s", fullpath);

        // ファイル名の取得
        std::string fullpath_ = fullpath;
        std::string::size_type startPos = fullpath_.find_last_of("/");
        std::string filename = fullpath_.substr(startPos + 1, fullpath_.length());

        std::string::size_type endPos = filename.find_last_of(".");
        filename = filename.substr(0, endPos);
        //CCLOG("getFilename after: %s", filename.c_str());
        return filename;
    }
}}
