//
//  downloader.h
//  chaos
//
//  ダウンローダー
//
//  Created by 何 利強 on 2016/09/06.
//
//

#ifndef downloader_h
#define downloader_h

#include <curl/curl.h>
#include "cocos-ext.h"
#include "cocos2d.h"

#include "parameter/download_parameter.h"

USING_NS_CC;
USING_NS_CC_EXT;

namespace Chaos {
namespace ResourcesManager {

class Unziper;

class Downloader {
public:
    /**
     * @brief ダウンローダーを作成する
     * @param[in] iUnziper 解凍者
     * @param[in] iDownloaderNo ダウンローダーNo
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iIsBackgroundDownload バックグラウンドDLフラグ
     */
    static Downloader* create(Unziper* iUnziper, const S32 iDownloaderNo, const S32 iDownloadIndex,
                              const Bool iIsBackgroundDownload = false);
    ~Downloader();

    /**
     * @brief ダウンロードステート
     */
    typedef enum TDownloadState {
        kTDownloadStateInvalid = -1,
        /** @brief アイドル */
        kTDownloadStateIdle,
        /** @brief 一時停止中 */
        kTDownloadStatePausing,
        /** @brief ダウンロード中 */
        kTDownloadStateDownloading,
        /** @brief 接続中 */
        kTDownloadStateConnecting,
        /** @brief リトライ */
        kTDownloadStateRetry,
        /** @brief 完了 */
        kTDownloadStateCompleted,
        /** @brief 接続失敗（リトライができる） */
        kTDownloadStateConnectFailed,
        /** @brief タイムアウト（リトライができる） */
        kTDownloadStateTimeOut,
        /** @brief エラー（リトライができる、通信エラーなど） */
        kTDownloadStateError,
        /** @brief 例外（リトライができない） */
        kTDownloadStateException,
        kTDownloadStateMax
    } TDownloadState;

    /**
     * @brief ダウンロードを開始する
     */
    const void StartDownload();

    /**
     * @brief 停止してるかどうかのチェック
     * @return 停止フラグ
     */
    const Bool isStoped();

    /**
     * @brief ダウンロードを一時停止にする
     */
    const void Pause();

    /**
     * @brief ダウンロードを続く
     */
    const void Continue();

    /**
     * @brief ダウンロードをリセットする
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iIsBackgroundDownload バックグラウンドDLフラグ
     */
    const void Reset(const S32 iDownloadIndex,
                     const Bool iIsBackgroundDownload = false);

    /**
     * @brief ダウンロードをリトライする
     */
    const void Retry();

    /**
     * @brief ダウンロードをキャンセルする
     */
    const void Cancel();

    /**
     * @brief リトライできるかどうかの判定
     * @return リトライできるかどうかのフラグ
     */
    const Bool isRetryAble();

    /**
     * @brief 失敗したかどうかの判定
     * @return 失敗したかどうかのフラグ
     */
    const Bool isFailed();

    /**
     * @brief 解凍者を設定する
     * @param[in] iUnziper 解凍者
     */
    const void SetUnziper(Unziper* iUnziper);

    /**
     * @brief 接続中であるかどうかの判定
     * @return 接続中フラグ
     */
    inline const Bool isConnecting() const {
        return (kTDownloadStateConnecting == this->state_);
    };
    /**
     * @brief 一時停止をチェックする
     * @return 一時停止フラグ
     */
    inline const Bool isPausing() const {
        return (kTDownloadStatePausing == this->state_);
    }

    /**
     * @brief キャンセルされたかどうかのチェック
     * @return キャンセルフラグ
     */
    inline const Bool isCanceled() const { return this->isCanceled_; };

    /**
     * @brief バックグラウンドDLのフラグを設定する
     * @param[in] iDownloaderIndex ダウンローダーNo
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iIsBackgroundDownload バックグラウンドDLのフラグ
     */
    inline const void SetDownloadInfo(const S32 iDownloaderNo,
                                      const S32 iDownloadIndex,
                                      const Bool iIsBackgroundDownload) {
        this->downloader_no_ = iDownloaderNo;
        this->download_index_ = iDownloadIndex;
        this->isBackgroundDownload_ = iIsBackgroundDownload;
    };

    /**
     * @brief ダウンロードインデックスを取得する
     * @return ダウンロードインデックス
     */
    inline const S32 getDownloadIndex() const { return this->download_index_; }

protected:
    Downloader();

private:
    /** @brief ダウンロードパラメーター */
    JOKER::DownloadParameter* download_parameter_;
    /** @brief 解凍者 */
    Unziper* unziper_;

    /** @brief ダウンローダーNo */
    S32 downloader_no_;
    /** @brief ダウンロードインデックス */
    S32 download_index_;

    /** @brief バックグラウンドDLフラグ */
    Bool isBackgroundDownload_;

    /** @brief ダウンロード用のCURL */
    JOKER::TWorkCurl workCurl_;

    /** @brief キャンセルフラグ */
    Bool isCanceled_;

    /** @brief ダウンロードステート */
    TDownloadState state_;

    /**
     * @brief CURLのオプションを初期化にする
     * @param[in] iWriteBuff 書き込む用バファー
     */
    CURL* InitCurlOption(std::vector<char>* iWriteBuff);

    /**
     * \brief ターゲットをダウンロードする
     * \param[in] iCurl CURL
     * \param[in] iDownloadTarget ダウンローダーターゲット情報
     * \param[in] iWriteBuffer 書き込む用バッファー
     */
    const TDownloadState DownloadByTargetInfo(
        CURL* iCurl, JOKER::TResourceInfo* iDownloadTarget,
        std::vector<char>& iWriteBuffer);

    /**
     * \brief ファイルをダウンロードする
     * \param[in] iDownloader ダウンローダー
     */
    static void* Download(void* iDownloader);
};
}
}

#endif /* downloader_h */
