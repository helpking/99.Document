//
//  download_parameter_types.h
//  chaos
//
//  Created by 何 利強 on 2016/09/06.
//
//

#ifndef download_parameter_types_h
#define download_parameter_types_h

#include <queue>

#include "application/joker_application_types.h"
#include "cocos-ext.h"
#include "cocos2d.h"

#include "pThread.h"
#include "MasterDBInfo.h"

JOKER_BEGIN_NAMESPACE

#define FILE_NAME_MAX_LEN                  511+1
#define DOWNLOAD_URL_MAX_LEN               511+1
#define REFRESH_INTERVAL_TIME              0.1f
#define DL_RES_COMMON_BUFFER_MAX_LEN       1023+1
#define API_RES_GET_REQUEST_BUFFER_MAX_LEN 4095+1

// 都度DL最大タイムアウト時間（単位：秒）
#define DL_TIME_OUT                        60.0f

/**
 * @brief リソースタイプ
 */
typedef enum TResourceType {
    kTResourceTypeInvalid = 0,
    /** @brief 1:チャプター */
    kTResourceTypeChapter,
    /** @brief 2:初回 */
    kTResourceTypeFirst,
    /** @brief 3:カード */
    kTResourceTypeCard,
    /** @brief 4:ユーザアバター */
    kTResourceTypeUserAvatar,
} TResourceType;

/**
 * スレッドセーフなキュー
 */
template <class T>
struct TThreadSafeQueue {
    std::queue<T> queue_;
    pthread_mutex_t mutex_;
    
    TThreadSafeQueue<T>() { pthread_mutex_init(&mutex_, NULL); }
    ~TThreadSafeQueue<T>() { pthread_mutex_destroy(&mutex_); }
    void Push(T v) {
        pthread_mutex_lock(&mutex_);
        queue_.push(v);
        pthread_mutex_unlock(&mutex_);
    }
    void Clear()
    {
        pthread_mutex_lock(&mutex_);
        while(!queue_.empty()){
            queue_.pop();
        }
        pthread_mutex_unlock(&mutex_);
    }
    T Pop(const bool lockFlg = true) {
        const bool isEmpty = queue_.empty();
        JOKER_ASSERT(!isEmpty);
        // ロックが有効にする場合、スレッドをロックする
        if (lockFlg == true) {
            pthread_mutex_lock(&mutex_);
        }
        // キューで、残り情報がない場合、無条件でロックする
        else if (isEmpty == true) {
            pthread_mutex_lock(&mutex_);
        }
        T v = NULL;
        if(!isEmpty) {
            v = queue_.front();
            queue_.pop();
        }
        pthread_mutex_unlock(&mutex_);
        return v;
    }
    bool Empty(const bool unlockFlg = true) {
        pthread_mutex_lock(&mutex_);
        const bool result = queue_.empty();
        // アンロックが有効にする場合、スレッドをアンロックする
        if (unlockFlg == true) {
            pthread_mutex_unlock(&mutex_);
        }
        // キューで、残り情報がない場合、無条件でアンロックする
        else if (result == true) {
            pthread_mutex_unlock(&mutex_);
        }
        return result;
    }
};

/**
 * \brief 構造体：都度DLチェック用のリソース情報定義
 */
typedef struct TDownloadCheckResourceInfo
{
    
    /** @brief チェックタイプタイプ */
    TResourceType checkType;
    /** \brief チェックファイル（チェックタイプがユーザアバターの場合のみ、有効） */
    Char checkFileName[FILE_NAME_MAX_LEN];
    /** @brief チェック用の詳細ID */
    S64 checkDetailId;
    
    inline TDownloadCheckResourceInfo()
    {
        Clear();
    }
    
    inline void Clear()
    {
        checkType = kTResourceTypeInvalid;
        checkFileName[0] = '\0';
        checkDetailId = -1;
    }
    
    inline void setCheckResInfo(const char* iResFileName)
    {
        checkType = kTResourceTypeUserAvatar;
        
        strncpy(checkFileName, iResFileName, sizeof(checkFileName));
        checkFileName[sizeof(checkFileName)-1] = 0;
        
        checkDetailId = -1;
    }
    
    inline void setCheckResInfo(const TResourceType iCheckType, const S32 iCheckDetailId)
    {
        checkType = iCheckType;
        checkFileName[0] = '\0';
        checkDetailId = iCheckDetailId;
    }
}TDownloadCheckResourceInfo;
/** \brief 構造体：都度DLチェック用のリソース詳細情報定義 */
typedef struct std::vector<TDownloadCheckResourceInfo> TDownloadCheckDetailsInfo;

/**
 * @brief 構造体：リソース情報定義
 */
typedef struct TResourceInfo {
    S32 resourceId_;
    /** @brief ダウンロード完了フラグ */
    Bool downloaded_;
    /** @brief 解凍完了フラグ */
    Bool unziped_;
    unsigned long dataSize_;
    void* data_;

    // 都度DLで追加フラグ（true:即時ダウンロードリソース;false:必要な時のみ、ダウンロードリソース）
    Bool syncFlg_;
    // v3.12.0 都度DL（カード）実装で追加する
    /** @brief リソースタイプ */
    TResourceType resourceType_;
    /** @brief 詳細ID */
    S64 detailId_;
    /** @brief 削除フラグ */
    Bool deleted_;
    /** @brief ローカルDBへ退避されたかどうかのフラグ */
    Bool localDbSaved_;
    /** @brief 更新日付（単位：ミリ秒） */
    S64 updateDate_;

    std::string downloadUrl_;
    
    TResourceInfo() { clear(); }

    void clear() {
        resourceId_ = -1;
        downloaded_ = false;
        unziped_ = false;
        dataSize_ = 0;
        data_ = NULL;
        downloadUrl_ = "";

        // 都度DLで追加するもの(v3.6.0から)
        syncFlg_ = false;
        // 都度DLで追加するもの(v3.12.0から)
        resourceType_ = kTResourceTypeInvalid;
        detailId_ = -1;
        localDbSaved_ = false;
        deleted_ = false;
        updateDate_ = -1;
    }
} TResourceInfo;

/**
 * @brief 構造体：リソース情報リスト定義
 */
typedef struct TResourcesListInfo {
    /** @brief カウンター */
    S32 count_;
    /** @brief データー */
    TResourceInfo* data_;
} TResourcesListInfo;

/**
 * @brief 構造体：ダウンロード詳細情報定義
 */
typedef struct TDownloadDetailInfo {
    /** @brief ダウンロードのターゲットズへ追加するため、重複チェック用のチェックリスト */
    std::vector<S32> download_targets_add_check_list_;
    /** @brief ダウンロードのターゲットズ */
    JOKER::TThreadSafeQueue<JOKER::TResourceInfo*> download_targets_;
    /** @brief 解凍のターゲットズリスト */
    std::vector<JOKER::TResourceInfo*> unzip_targets_;
    /** @brief ターゲットズカウント*/
    S32 targets_count;
    /** @brief ダウンロード完了カウント */
    S32 downloaded_count;
    /** @brief 解凍完了カウント */
    S32 unziped_count;
} TDownloadDetailInfo;

/**
 * @brief 構造体：ダウンロード情報定義
 */
typedef struct TDownloadInfo {
    /** @brief ダウンロード用のインデックス */
    S32 index;
    /** @brief ダウンロード詳細情報 */
    TDownloadDetailInfo details_;
} TDownloadInfo;
typedef struct std::vector<TDownloadInfo*> TDownloadInfos;

/**
 * @brief 構造体：ダウンロードカウント情報定義
 */
typedef struct TDownloadedCountInfo {
    /** @brief ターゲットズカウント*/
    S32 targets_count;
    /** @brief ダウンロード完了カウント */
    S32 downloaded_count;
    /** @brief 解凍完了カウント */
    S32 unziped_count;
    /** @brief 完成率 */
    F32 completed_rate;
} TDownloadedCountInfo ;

/**
 * @brief 構造体：curl用のスレッド作業データ
 */
struct TWorkCurl {
    pthread_t thread_;
    pthread_cond_t sleep_condition_;
    pthread_mutex_t sleep_mutex_;
    F32 unit_progress_;
    const char* downloading_zip_filename_;

    TWorkCurl() { clear(); }

    void clear() {
        // スレッドの初期化
        thread_ = NULL;
        pthread_cond_init(&sleep_condition_, NULL);
        pthread_mutex_init(&sleep_mutex_, NULL);

        unit_progress_ = 0;
        downloading_zip_filename_ = NULL;
    }
    
    void destory() {
        thread_ = NULL;
        pthread_cond_destroy(&sleep_condition_);
        pthread_mutex_destroy(&sleep_mutex_);
        
        unit_progress_ = 0;
        downloading_zip_filename_ = NULL;
    }
};

JOKER_END_NAMESPACE

#endif /* download_parameter_types_h */
