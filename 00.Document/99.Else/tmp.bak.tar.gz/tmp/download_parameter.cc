//
//  download_parameter.cc
//  chaos
//
//  ダウンロード用のパラメーター
//
//  Created by 何 利強 on 2016/09/06.
//
//
#include <sqlite3.h>

#include "ResourcesManager.h"
#include "SQLiteC++.h"
#include "Util.h"
#include "library/sql.h"

#include "MasterDataManager/DatabaseManager.h"
#include "MasterOtherData.h"
#include "parameter/download_parameter.h"
// 3.12不具合修正の暫定対応用（checkHealthWithDownloadResources）
#include "ApplicationConfig.h"

JOKER_BEGIN_NAMESPACE

#define DOWNLOAD_RESOURCE_TABLE_NAME "DLResourcesInfo"  // リソース情報テーブル
#define DOWNLOAD_RESOURCE_TABLE_COLUMN_TYPE "Type"
#define DOWNLOAD_RESOURCE_TABLE_COLUMN_DETAIL_ID "DetailId"
#define DOWNLOAD_RESOURCE_TABLE_COLUMN_DELETED "Deleted"

DownloadParameter::DownloadParameter()
    : addCheckLockFlg_(false),
      lastResourceId_(-1),
      lastResourceUpdateDate_(-1),
      dlResourceInfoCount_(0),
      interruptAllResourceSaveThread_(false),
      isAllResourceSaveThreadStoped_(true){
    // スレッド用の変数初期化
    pthread_mutex_init(&sleep_info_update_mutex_, NULL);

    this->download_infos_.clear();
    // リソース情報
    this->resources_.count_ = 0;
    this->resources_.data_ = NULL;

    // ダウンロード用のチェック詳細
    this->check_details_.clear();
}
DownloadParameter::~DownloadParameter() {
    // スレッド用の変数
    pthread_mutex_destroy(&sleep_info_update_mutex_);

    this->download_infos_.clear();

    // メモリ解放
    this->destroyMemory();
}

/**
 * @brief 読み込む用のリソース情報を取得する
 * @param[in] iResourceId リソースID
 * @return リソース情報
 */
const TResourceInfo* DownloadParameter::getResourceInfoWithReadOnly(
    const S32 iResourceId) const {
    const TResourceInfo* pLoop = resources_.data_;
    S32 countTmp = 0;
    while (pLoop) {
        // メモリ上で超える場合
        if (countTmp >= resources_.count_) {
            break;
        }

        if (iResourceId == pLoop->resourceId_) {
            return pLoop;
        }

        ++countTmp;
        ++pLoop;
    }
    return NULL;
}

/**
 * @brief 読み込む用のリソース情報を取得する
 * @param[in] iResourceType リソースタイプ
 * @param[in] iDetailId 詳細ID
 * @return リソース情報
 */
const TResourceInfo* DownloadParameter::getResourceInfoWithReadOnly(
    const TResourceType iResourceType, const S64 iDetailId) const {
    const TResourceInfo* pLoop = resources_.data_;
    S32 countTmp = 0;
    while (pLoop) {
        // メモリ上で超える場合
        if (countTmp >= resources_.count_) {
            break;
        }

        if ((iResourceType == pLoop->resourceType_) &&
            (iDetailId == pLoop->detailId_)) {
            return pLoop;
        }

        ++countTmp;
        ++pLoop;
    }
    return NULL;
}

/**
 * @brief 書き込む用のリソース情報を取得する
 * @param[in] iResourceId リソースID
 * @return リソース情報
 */
TResourceInfo* DownloadParameter::getResourceInfoWithWritable(
    const S32 iResourceId) {
    TResourceInfo* pLoop = resources_.data_;
    S32 countTmp = 0;
    while (pLoop) {
        // メモリ上で超える場合
        if (countTmp >= resources_.count_) {
            break;
        }

        if (iResourceId == pLoop->resourceId_) {
            return pLoop;
        }

        ++countTmp;
        ++pLoop;
    }

    // 未設定の場合、次の空いてるレコードアドレスを探す
    pLoop = resources_.data_;
    countTmp = 0;
    while (pLoop) {
        if (-1 == pLoop->resourceId_) {
            return pLoop;
        }

        // メモリ上で超える場合
        if (countTmp >= resources_.count_) {
#ifdef RUNTIME_DOWNLOAD_DEBUG
            JOKER_DEBUG(
                "\n\n*************************************\n\n"
                "\n\n -> getResourceInfoWithWritable(0) <- \n\n"
                "[Warning] Out of the resource memory range!!!"
                "[%d/%d][ResourceId:%d]"
                "\n\n*************************************\n\n",
                countTmp, resources_.count_, iResourceId);
#else
            JOKER_ASSERT_MSG(
                false,
                "Out of the resource memory range!!![%d/%d][ResourceId:%d]",
                countTmp, resources_.count_, iResourceId);
#endif
            return NULL;
        }

        ++countTmp;
        ++pLoop;
    }
    return pLoop;
}

/**
 * @brief 書き込む用のリソース情報を取得する
 * @param[in] iResourceType リソースタイプ
 * @param[in] iDetailId 詳細ID
 * @return リソース情報
 */
TResourceInfo* DownloadParameter::getResourceInfoWithWritable(
    const JOKER::TResourceType iResourceType, const S64 iDetailId) {
    TResourceInfo* pLoop = resources_.data_;
    S32 countTmp = 0;
    while (pLoop) {
        // メモリ上で超える場合
        if (countTmp >= resources_.count_) {
            break;
        }

        if ((iResourceType == pLoop->resourceType_) &&
            (iDetailId == pLoop->detailId_)) {
            return pLoop;
        }

        ++countTmp;
        ++pLoop;
    }

    // 未設定の場合、次の空いてるレコードアドレスを探す
    pLoop = resources_.data_;
    countTmp = 0;
    while (pLoop) {
        if (-1 == pLoop->resourceId_) {
            return pLoop;
        }

        // メモリ上で超える場合
        if (countTmp >= resources_.count_) {
#ifdef RUNTIME_DOWNLOAD_DEBUG
            JOKER_DEBUG(
                "\n\n*************************************\n\n"
                "\n\n -> getResourceInfoWithWritable(1) <- \n\n"
                "[Warning] Out of the resource memory range!!!"
                "[%d/%d][ResourceType:%d DetailId:%lld]"
                "\n\n*************************************\n\n",
                countTmp, resources_.count_, (S32)iResourceType, iDetailId);
#else
            JOKER_ASSERT_MSG(false,
                             "Out of the resource memory "
                             "range!!![%d/%d][ResourceType:%d DetailId:%lld]",
                             countTmp, resources_.count_, (S32)iResourceType,
                             iDetailId);
#endif
            return NULL;
        }

        ++countTmp;
        ++pLoop;
    }
    return pLoop;
}

/**
 * @brief リソース情報を追加する
 * @param[in] iResourceInfo リソース情報
 */
const void DownloadParameter::addResourceInfo(
    const TResourceInfo* iResourceInfo) {
    // 更新ターゲットを取得する
    TResourceInfo* pTargetLoop =
        this->getResourceInfoWithWritable(iResourceInfo->resourceId_);
    if (!pTargetLoop) {
        return;
    }

    // データをコピーする
    pTargetLoop->resourceId_ = iResourceInfo->resourceId_;

    // 通常DLで、ダウンロードするターゲットの場合、
    // ダウンロード完了フラグ＆解凍完了フラグ強制に「true」にする
    if (iResourceInfo->syncFlg_) {
        pTargetLoop->downloaded_ = true;
        pTargetLoop->unziped_ = true;
    } else {
        pTargetLoop->downloaded_ = iResourceInfo->downloaded_;
        pTargetLoop->unziped_ = iResourceInfo->unziped_;
    }
    pTargetLoop->dataSize_ = iResourceInfo->dataSize_;
    pTargetLoop->data_ = iResourceInfo->data_;

    pTargetLoop->syncFlg_ = iResourceInfo->syncFlg_;
    pTargetLoop->resourceType_ = iResourceInfo->resourceType_;
    pTargetLoop->detailId_ = iResourceInfo->detailId_;
    pTargetLoop->deleted_ = iResourceInfo->deleted_;
    pTargetLoop->updateDate_ = iResourceInfo->updateDate_;
    pTargetLoop->localDbSaved_ = iResourceInfo->localDbSaved_;
    pTargetLoop->downloadUrl_ = iResourceInfo->downloadUrl_;
}

/**
 * @brief チェック用の情報をチェックする（ファイル名）
 * @param[in] iCheckFileName チェックファイル名
 */
void DownloadParameter::addCheckDetailInfo(const Char* iCheckFileName) {
    if (this->addCheckLockFlg_) {
        this->check_details_.clear();
        return;
    }

    // ファイル名のNULLチェック
    if ((NULL == iCheckFileName) || (std::strcmp("", iCheckFileName) == 0)) {
        return;
    }

    // リソースファイルが既に存在する場合、スキップする
    if (this->isFileExist(iCheckFileName) == true) {
        return;
    }

    // 存在チェック
    std::vector<JOKER::TDownloadCheckResourceInfo>::iterator itBegin =
        this->check_details_.begin();
    std::vector<JOKER::TDownloadCheckResourceInfo>::iterator itEnd =
        this->check_details_.end();
    Bool fileExistFlg = false;
    for (std::vector<JOKER::TDownloadCheckResourceInfo>::iterator itLoop =
             itBegin;
         itLoop != itEnd; ++itLoop) {
        if (std::strcmp(itLoop->checkFileName, iCheckFileName) == 0) {
            fileExistFlg = true;
            break;
        }
    }
    // 既に追加されたフィアルが、スキップする
    if (fileExistFlg) {
        return;
    }

    JOKER::TDownloadCheckResourceInfo resInfoTmp;
    resInfoTmp.setCheckResInfo(iCheckFileName);
    this->check_details_.push_back(resInfoTmp);
}

/**
 * @brief チェック用の情報をチェックする
 * @param[in] iCheckType チェックタイプ
 * @param[in] iCheckDetailId チェック用の詳細ID
 */
void DownloadParameter::addCheckDetailInfo(const TResourceType iCheckType,
                                           const S32 iCheckDetailId) {
    if (this->addCheckLockFlg_) {
        this->check_details_.clear();
        return;
    }

    // 現在カードのみ、チェック情報へ、追加しない
    if (kTResourceTypeCard != iCheckType) {
        return;
    }

    // 既にダウンロードされた場合、チェック情報へ、追加しない
    if (this->isResourceDownloadedByDetailId(iCheckType, iCheckDetailId)) {
        return;
    }

    // 存在チェック
    std::vector<JOKER::TDownloadCheckResourceInfo>::iterator itBegin =
        this->check_details_.begin();
    std::vector<JOKER::TDownloadCheckResourceInfo>::iterator itEnd =
        this->check_details_.end();
    Bool fileExistFlg = false;
    for (std::vector<JOKER::TDownloadCheckResourceInfo>::iterator itLoop =
             itBegin;
         itLoop != itEnd; ++itLoop) {
        if ((iCheckType == itLoop->checkType) &&
            (iCheckDetailId == itLoop->checkDetailId)) {
            fileExistFlg = true;
            break;
        }
    }
    // 既に追加されたフィアルが、スキップする
    if (fileExistFlg) {
        return;
    }

    JOKER::TDownloadCheckResourceInfo resInfoTmp;
    resInfoTmp.setCheckResInfo(iCheckType, iCheckDetailId);
    this->check_details_.push_back(resInfoTmp);
}

/**
 * @brief リソース情報退避用のメモリを初期化にする
 * @param[in] iResourcesCount リソースカウンター
 */
void DownloadParameter::initMemorySize(const S32 iResourcesCount) {
    if (iResourcesCount <= 0) {
        return;
    }

    // 既に存在する情報をクリアすため、メモリを解放する
    destroyMemory();

    resources_.count_ = iResourcesCount;
    resources_.data_ = new TResourceInfo[iResourcesCount];
}

/**
 * @brief リソース情報退避用のメモリをを解放する
 */
void DownloadParameter::destroyMemory() {
    resources_.count_ = 0;
    if (resources_.data_) {
        delete[] resources_.data_;
    }
}

/**
 * \brief ファイルの存在チェック
 * @param[in] iFileName ファイル名
 */
const Bool DownloadParameter::isFileExist(const char* iFileName) {
    if (!iFileName) {
        return false;
    }

    // リソースファイルフルパスの取得
    CCString* fileFullPathTmp = CCString::createWithFormat(
        "%s%s",
        Chaos::ResourcesManager::ResourcesManager::sharedResourcesManager()
            ->getDefaultPath()
            .c_str(),
        iFileName);
    if (Chaos::ResourcesManager::ResourcesManager::sharedResourcesManager()
            ->isExist(*fileFullPathTmp)) {
        //        JOKER_DEBUG(
        //            "[Debug:C I/A][DlResource]DownloadParameter::isFileExist::
        //            -> "
        //            "true.\n");
        return true;
    }

    return false;
}

/**
 * @brief ダウンロード詳細情報を取得する
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @return ダウンロード詳細情報
 */
TDownloadDetailInfo* DownloadParameter::getDownloadDetail(
    const S32 iDownloadIndex) {
    if (-1 >= iDownloadIndex) {
        return NULL;
    }

    std::vector<TDownloadInfo*>::iterator itBegin =
        this->download_infos_.begin();
    std::vector<TDownloadInfo*>::iterator itEnd = this->download_infos_.end();
    for (std::vector<TDownloadInfo*>::iterator itLoop = itBegin;
         itLoop != itEnd; ++itLoop) {
        if (iDownloadIndex == (*itLoop)->index) {
            return &((*itLoop)->details_);
        }
    }
    return NULL;
}

/**
 * @brief 指定されたカレントダウンロードインデックスで、
 *        前回残ったダウンロードターゲットズ情報ををクリアする
 * @param[in] iCurrentDownloadIndex カレントダウンロードインデックス
 */
const void DownloadParameter::clearDownloadDetailsByCurrentDownloadIndex(
    const S32 iCurrentDownloadIndex) {
    if (-1 >= iCurrentDownloadIndex) {
        return;
    }

    std::vector<S32> clearList;

    std::vector<TDownloadInfo*>::iterator itBegin =
        this->download_infos_.begin();
    std::vector<TDownloadInfo*>::iterator itEnd = this->download_infos_.end();
    for (std::vector<TDownloadInfo*>::iterator itLoop = itBegin;
         itLoop != itEnd; ++itLoop) {
        if (iCurrentDownloadIndex > (*itLoop)->index) {
            clearList.push_back((*itLoop)->index);
        }
    }

    std::vector<S32>::const_iterator itCBegin = clearList.begin();
    std::vector<S32>::const_iterator itCEnd = clearList.end();
    for (std::vector<S32>::const_iterator itCLoop = itCBegin; itCLoop != itCEnd;
         ++itCLoop) {
        this->removeDownloadDetailByIndex((*itCLoop));
    }
}

/**
 * @brief 指定されたダウンロードインデックスで、ダウンロード詳細情報を削除する
 * @param[in] iIsBackgroundDownload バックグラウンドDLフラグ
 */
const void DownloadParameter::removeDownloadDetailByIndex(
    const S32 iDownloadIndex) {
    if (-1 >= iDownloadIndex) {
        return;
    }

    std::vector<TDownloadInfo*>::iterator itBegin =
        this->download_infos_.begin();
    std::vector<TDownloadInfo*>::iterator itEnd = this->download_infos_.end();
    for (std::vector<TDownloadInfo*>::iterator itLoop = itBegin;
         itLoop != itEnd; ++itLoop) {
        if (iDownloadIndex == (*itLoop)->index) {
            JOKER_DEBUG(
                "\n[Debug:C "
                "I/A]DownloadParameter::removeDownloadDetailByIndex::Remove "
                "Download Index::%d\n",
                iDownloadIndex);
            TDownloadInfo* downloadDetail = *itLoop;
            this->download_infos_.erase(itLoop);
            delete downloadDetail;
            break;
        }
    }
}

/**
 * @brief 都合DL：一括ダウンロード用のターゲットズ一覧を作成する
 * @param[in] iDownloadIndex ダウンロードインデックス
 */
const void DownloadParameter::createRuntimeDownloadTargetsForAll(
    const S32 iDownloadIndex) {
    TResourceInfo* pLoop = resources_.data_;
    S32 countTmp = 0;
    while (pLoop) {
        // メモリ上で超える場合
        if (countTmp >= resources_.count_) {
            break;
        }
        // ダウンロードされた、かつ、解凍された場合、完了として、スキップする
        if ((pLoop->downloaded_) && (pLoop->unziped_)) {
            ++countTmp;
            ++pLoop;
            continue;
        }

        this->pushDownloadTargetInfo(iDownloadIndex, pLoop);

        ++countTmp;
        ++pLoop;
    }
}

/**
 * @brief カードのダウンロードチェックを行う
 * @param[in] iResourceType リソースタイプ
 * @param[in] iDetailId 詳細ID
 * @return リソースのダウンロードフラグ
 */
const Bool DownloadParameter::isResourceDownloadedByDetailId(
    const TResourceType iResourceType, const S32 iDetailId) const {
    TResourceInfo* pLoop = resources_.data_;
    S32 countTmp = 0;
    while (pLoop) {
        // メモリ上で超える場合
        if (countTmp >= resources_.count_) {
#ifdef RUNTIME_DOWNLOAD_DEBUG
            JOKER_DEBUG(
                "\n\n*************************************\n\n"
                "[Warning] The resource is not exist in database!!!"
                "[ResourceType:%d DetailID:%d]"
                "\n\n*************************************\n\n",
                (S32)iResourceType, iDetailId);
#else
            JOKER_ASSERT_MSG(false,
                             "The resource is not exist in "
                             "database!!![ResourceType:%d DetailID:%d]",
                             (S32)iResourceType, iDetailId);
#endif
            break;
        }
        if ((iResourceType == pLoop->resourceType_) &&
            (iDetailId == pLoop->detailId_)) {
            if ((pLoop->downloaded_) && (pLoop->unziped_)) {
                return true;
            }
            break;
        }

        ++countTmp;
        ++pLoop;
        continue;
    }
    return false;
}

/**
 * @brief ダウンロードターゲットの存在チェックを行う
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iIsBackgroundDownloadFlg バックグラウンドDLフラグ
 * @return ダウンロードターゲットズの存在フラグ
 */
const Bool DownloadParameter::isDownloadTargetsExist(
    const S32 iDownloadIndex, const Bool iIsBackgroundDownloadFlg) {
    const TDownloadedCountInfo countInfo =
        this->getDownloadedCountInfo(iDownloadIndex);
    return ((countInfo.targets_count > 0) ? true : false);
}

/**
 * @brief チェック詳細情報(ファイルパスで)の存在チェックを行う
 * @return チェック詳細情報(ファイルパスで)の存在フラグ
 */
const Bool DownloadParameter::isCheckDetailInfoExistByFilePath() const {
    std::vector<TDownloadCheckResourceInfo>::const_iterator itBegin =
        this->check_details_.begin();
    std::vector<TDownloadCheckResourceInfo>::const_iterator itEnd =
        this->check_details_.end();
    for (std::vector<TDownloadCheckResourceInfo>::const_iterator itLoop =
             itBegin;
         itLoop != itEnd; ++itLoop) {
        if (kTResourceTypeUserAvatar == itLoop->checkType) {
            return true;
        }
    }
    return false;
}

/**
 * @brief 全ターゲットズがダウンロードされたかどうかのチェックを行う
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iIsBackgroundDownloadFlg バックグラウンドDLフラグ
 * @return 全ダウンロードフラグ
 */
Bool DownloadParameter::isAllTargetsDownloaded(
    const S32 iDownloadIndex, const Bool iIsBackgroundDownloadFlg) {
    // バックグラウンドDLの場合
    if (iIsBackgroundDownloadFlg) {
        Bool isAllDownloaded = true;
        TResourceInfo* pLoop = resources_.data_;
        S32 countTmp = 0;
        while (pLoop) {
            // メモリ上で超える場合
            if (countTmp >= resources_.count_) {
                break;
            }

            if (!pLoop->downloaded_) {
                isAllDownloaded = false;
                break;
            }

            ++countTmp;
            ++pLoop;
        }
        return isAllDownloaded;
        // 都度DLの場合
    } else {
        const TDownloadedCountInfo countInfo =
            this->getDownloadedCountInfo(iDownloadIndex);
        return (countInfo.targets_count == countInfo.downloaded_count);
    }
}

/**
 * @brief 全ターゲットズが解凍されたかどうかのチェックを行う
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iIsBackgroundDownloadFlg バックグラウンドDLフラグ
 * @return 全解凍フラグ
 */
Bool DownloadParameter::isAllTargetsUnziped(
    const S32 iDownloadIndex, const Bool iIsBackgroundDownloadFlg) {
    // バックグラウンドDLの場合
    if (iIsBackgroundDownloadFlg) {
        Bool isAllUnziped = true;
        TResourceInfo* pLoop = resources_.data_;
        S32 countTmp = 0;
        while (pLoop) {
            // メモリ上で超える場合
            if (countTmp >= resources_.count_) {
                break;
            }

            if (!pLoop->unziped_) {
                isAllUnziped = false;
                break;
            }

            ++countTmp;
            ++pLoop;
        }
        return isAllUnziped;

        // 都度DLの場合
    } else {
        TDownloadDetailInfo* downloadDetail =
            this->getDownloadDetail(iDownloadIndex);
        if (!downloadDetail) {
            return true;
        }
        return (downloadDetail->targets_count == downloadDetail->unziped_count);
    }
};

/**
 * @brief ダウンロード用のターゲットズ情報を初期化にする
 * @param[in] iDownloadIndex ダウンロードインデックス
 */
void DownloadParameter::initDownloadTargetsInfo(const S32 iDownloadIndex) {
    if (-1 >= iDownloadIndex) {
        return;
    }

    TDownloadDetailInfo* downloadDetail =
        this->getDownloadDetail(iDownloadIndex);
    if (!downloadDetail) {
        return;
    }

    // ターゲットをクリアする
    downloadDetail->targets_count = 0;
    downloadDetail->downloaded_count = 0;
    downloadDetail->unziped_count = 0;
    downloadDetail->download_targets_add_check_list_.clear();
    downloadDetail->download_targets_.Clear();
    downloadDetail->unzip_targets_.clear();

    JOKER_DEBUG("\n[Debug:C I/A][%d]DownloadParameter::initDownloadTargetsInfo",
                iDownloadIndex);
}

/**
 * @brief ダウンロード用のターゲット情報を追加する
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iResourceId リソースID
 */
void DownloadParameter::pushDownloadTargetInfo(const S32 iDownloadIndex,
                                               const S32 iResourceId) {
    TResourceInfo* pTargetInfo = this->getResourceInfoWithWritable(iResourceId);
    if (!pTargetInfo) {
#ifdef RUNTIME_DOWNLOAD_DEBUG
        JOKER_DEBUG(
            "\n\n*************************************\n\n"
            "[Warning] The info of resource is not exist!!!"
            "[ResourceId:%d]"
            "\n\n*************************************\n\n",
            iResourceId);
#else
        JOKER_ASSERT_MSG(false,
                         "The info of resource is not exist!!![ResourceId:%d]",
                         iResourceId);
#endif
        return;
    }

    // 既に、ダウンロードされた場合、スキップする
    if (pTargetInfo->downloaded_ && pTargetInfo->unziped_) {
        return;
    }

    // ターゲットを追加する
    this->pushDownloadTargetInfo(iDownloadIndex, pTargetInfo);
}

/**
 * @brief ダウンロード用の情報を追加する
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iResourceType リソースタイプ
 * @param[in] iDetailId 詳細ID
 */
void DownloadParameter::pushDownloadTargetInfoByDetailId(
    const S32 iDownloadIndex, const JOKER::TResourceType iResourceType,
    const S64 iDetailId) {
    TResourceInfo* pTargetInfo =
        this->getResourceInfoWithWritable(iResourceType, iDetailId);
    if (!pTargetInfo) {
#ifdef RUNTIME_DOWNLOAD_DEBUG
        JOKER_DEBUG(
            "\n\n*************************************\n\n"
            "[Warning] The info of resource is not exist!!!"
            "[ResourceType:%d DetailId:%lld]"
            "\n\n*************************************\n\n",
            (S32)iResourceType, iDetailId);
#else
        JOKER_ASSERT_MSG(false,
                         "The info of resource is not exist!!![ResourceType:%d "
                         "DetailId:%lld]",
                         (S32)iResourceType, iDetailId);
#endif
        return;
    }

    // 既に、ダウンロードされた場合、スキップする
    if (pTargetInfo->downloaded_ && pTargetInfo->unziped_) {
        return;
    }

    // ターゲットを追加する
    this->pushDownloadTargetInfo(iDownloadIndex, pTargetInfo);
}

/**
 * @brief ダウンロード用の情報を追加する
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iResourceInfo リソース情報
 */
void DownloadParameter::pushDownloadTargetInfo(const S32 iDownloadIndex,
                                               TResourceInfo* iResourceInfo) {
    if (!iResourceInfo || (-1 >= iDownloadIndex)) {
#ifdef RUNTIME_DOWNLOAD_DEBUG
        JOKER_DEBUG(
            "\n\n*************************************\n\n"
            "[Warning] The info of resource is invalid[DownloadIndex:%d(%s)]!!!"
            "\n\n*************************************\n\n",
            iDownloadIndex, (iResourceInfo ? "" : "resource is null"));
#else
        JOKER_ASSERT_MSG(false, "The info of resource is invalid!!!");
#endif
        return;
    }

    Bool isExist = false;
    std::vector<TDownloadInfo*>::iterator itBegin =
        this->download_infos_.begin();
    std::vector<TDownloadInfo*>::iterator itEnd = this->download_infos_.end();
    for (std::vector<TDownloadInfo*>::iterator itLoop = itBegin;
         itLoop != itEnd; ++itLoop) {
        if (iDownloadIndex == (*itLoop)->index) {
            isExist = true;
            break;
        }
    }

    // ダウンロード詳細情報の存在チェック
    if (!isExist) {
        TDownloadInfo* newDownloadinfo = new TDownloadInfo;
        newDownloadinfo->index = iDownloadIndex;
        newDownloadinfo->details_.targets_count = 0;
        newDownloadinfo->details_.downloaded_count = 0;
        newDownloadinfo->details_.unziped_count = 0;
        newDownloadinfo->details_.download_targets_add_check_list_.clear();
        newDownloadinfo->details_.download_targets_.Clear();
        newDownloadinfo->details_.unzip_targets_.clear();

        this->download_infos_.push_back(newDownloadinfo);

        JOKER_DEBUG(
            "\n[Debug:C I/A][%d]DownloadParameter::pushDownloadTargetInfo::New "
            "Record",
            iDownloadIndex);
    }

    // カレントダウンロード詳細を取得する
    TDownloadDetailInfo* currentDownloadDetailInfo =
        this->getDownloadDetail(iDownloadIndex);
    JOKER_ASSERT_MSG(currentDownloadDetailInfo,
                     "The download detail info is not exist!!!");

    // 重複チェックを行う
    Bool isAdded = this->isDownloadTargetInfoAdded(currentDownloadDetailInfo,
                                                   iResourceInfo->resourceId_);
    if (isAdded) {
        return;
    }

    // ターゲットを追加する
    currentDownloadDetailInfo->download_targets_add_check_list_.push_back(
        iResourceInfo->resourceId_);
    currentDownloadDetailInfo->download_targets_.Push(iResourceInfo);
    currentDownloadDetailInfo->unzip_targets_.push_back(iResourceInfo);
    ++currentDownloadDetailInfo->targets_count;

    JOKER_DEBUG(
        "\n[Debug:C I/A][%d]DownloadParameter::pushDownloadTargetInfo::Add "
        "Target -> [%d]%d",
        iDownloadIndex, currentDownloadDetailInfo->targets_count,
        iResourceInfo->resourceId_);
}

/**
 * @brief ダウンロードターゲット情報が追加されたかどうかの判定
 * @param[in] iDownloadDetail ダウンロード詳細
 * @param[in] iResourceId リソースID
 * @return 追加されたフラグ
 */
const Bool DownloadParameter::isDownloadTargetInfoAdded(
    TDownloadDetailInfo* iDownloadDetail, const S32 iResourceId) {
    if (!iDownloadDetail) {
        return false;
    }

    // 重複チェックを行う
    Bool isAdded = false;
    std::vector<S32>::const_iterator itBegin =
        iDownloadDetail->download_targets_add_check_list_.begin();
    std::vector<S32>::const_iterator itEnd =
        iDownloadDetail->download_targets_add_check_list_.end();
    for (std::vector<S32>::const_iterator itLoop = itBegin; itLoop != itEnd;
         ++itLoop) {
        if (iResourceId == (*itLoop)) {
            isAdded = true;
            break;
        }
    }
    return isAdded;
}

/**
 * @brief ダウンロードターゲットズカウントを取得する
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @return ダウンロードターゲットズカウント
 */
S32 DownloadParameter::getDownloadTargetsCount(const S32 iDownloadIndex) {
    S32 targetCount = 0;
    TDownloadDetailInfo* downloadDetail =
        this->getDownloadDetail(iDownloadIndex);
    if (downloadDetail) {
        targetCount = downloadDetail->targets_count;
    }
    return targetCount;
}

#pragma mark -
#pragma mark Thread Safe

/**
 * @brief ダウンロードカウント情報を取得する
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @return ダウンロードカウント情報
 */
TDownloadedCountInfo DownloadParameter::getDownloadedCountInfo(
    const S32 iDownloadIndex) {
    TDownloadedCountInfo countInfo;

    TDownloadDetailInfo* downloadDetail =
        this->getDownloadDetail(iDownloadIndex);
    if (!downloadDetail) {
        countInfo.targets_count = 0;
        countInfo.downloaded_count = 0;
        countInfo.unziped_count = 0;
        countInfo.completed_rate = 0.0f;
        JOKER_DEBUG(
            "\n[Debug:C "
            "I/A][Warning]DownloadParameter::getDownloadedCountInfo::The "
            "download detail info is null or not "
            "created!!![DownloadIndex:%d]\n",
            iDownloadIndex);
        return countInfo;
    }

    countInfo.targets_count = downloadDetail->targets_count;
    countInfo.downloaded_count = downloadDetail->downloaded_count;
    countInfo.unziped_count = downloadDetail->unziped_count;

    // ターゲットがない場合、通るため「100%」にする
    if (0 >= countInfo.targets_count) {
        countInfo.completed_rate = 1.0f;
    } else {
        if (countInfo.unziped_count >= countInfo.targets_count) {
            countInfo.completed_rate = 1.0f;
        } else {
            countInfo.completed_rate =
                ((F32)(countInfo.downloaded_count + countInfo.unziped_count)) /
                ((F32)(countInfo.targets_count * 2));
        }
    }

    JOKER_DEBUG(
        "\n[Debug:C "
        "I/A]DownloadParameter::getDownloadedCountInfo::Count Info "
        "[%d]Target:%d Downloaded:%d Unziped:%d CompletedRate:%f \n",
        iDownloadIndex, countInfo.targets_count, countInfo.downloaded_count,
        countInfo.unziped_count, countInfo.completed_rate);

    return countInfo;
}

/**
 * @brief 解凍のターゲット情報を取得する
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iUnzipIndex 解凍のインデックス
 * @param[in] iIsBackgroundDownload バックグラウンドダウンロードフラグ
 */
TResourceInfo* DownloadParameter::getUnzipTargetInfo(
    const S32 iDownloadIndex, const S32 iUnzipIndex,
    const Bool iIsBackgroundDownload) {
    TResourceInfo* pTarget = NULL;
    // 都度DLの場合
    if (!iIsBackgroundDownload) {
        if ((0 <= iDownloadIndex) && (0 <= iUnzipIndex)) {
            TDownloadDetailInfo* downloadDetail =
                this->getDownloadDetail(iDownloadIndex);
            if (downloadDetail) {
                const S32 targetsCount = downloadDetail->targets_count;
                if (targetsCount <= 0) {
                    pTarget = NULL;
                } else {
                    pTarget = (downloadDetail->unzip_targets_[iUnzipIndex]);
                }
            } else {
                JOKER_DEBUG(
                    "\n[Debug:C "
                    "I/A][%d/"
                    "%d]DownloadParameter::getUnzipTargetInfo::DownloadDetail "
                    "is null",
                    iDownloadIndex, iUnzipIndex);
                pTarget = NULL;
            }
        } else {
            pTarget = NULL;
        }

    } else {
        TResourceInfo* pLoop = resources_.data_;
        S32 countTmp = 0;
        while (pLoop) {
            // メモリ上で超える場合
            if (countTmp >= resources_.count_) {
                break;
            }

            if (-1 >= pLoop->resourceId_) {
                continue;
            }

            if (pLoop->downloaded_ && (pLoop->unziped_ == false)) {
                pTarget = pLoop;
                break;
            }

            if (pTarget) {
                break;
            }

            ++countTmp;
            ++pLoop;
        }
    }
    return pTarget;
}

#pragma mark -
#pragma mark SqlLite

/**
 * @brief ダウンロード情報を初期化にする
 * @param[in] iNewResourcesCount
 * ダウンロードレスポンスから、返した新リソースカウンター
 */
const void DownloadParameter::initDownloadInfo(const S32 iNewResourcesCount) {
    // テーブルカラム：「タイプ」の存在チェック
    if (!isColumnExist(DOWNLOAD_RESOURCE_TABLE_NAME,
                       DOWNLOAD_RESOURCE_TABLE_COLUMN_TYPE)) {
        Bool bolFlg = this->addColumnToTable(
            DOWNLOAD_RESOURCE_TABLE_NAME, DOWNLOAD_RESOURCE_TABLE_COLUMN_TYPE,
            kTSQLiteDataTypeInteger);
        JOKER_ASSERT_MSG(bolFlg, "Column add failed!!![TableName:%s Column:%s]",
                         DOWNLOAD_RESOURCE_TABLE_NAME,
                         DOWNLOAD_RESOURCE_TABLE_COLUMN_TYPE);
    }

    // テーブルカラム：「詳細ID」の存在チェック
    if (!isColumnExist(DOWNLOAD_RESOURCE_TABLE_NAME,
                       DOWNLOAD_RESOURCE_TABLE_COLUMN_DETAIL_ID)) {
        Bool bolFlg = this->addColumnToTable(
            DOWNLOAD_RESOURCE_TABLE_NAME,
            DOWNLOAD_RESOURCE_TABLE_COLUMN_DETAIL_ID, kTSQLiteDataTypeInteger);
        JOKER_ASSERT_MSG(bolFlg, "Column add failed!!![TableName:%s Column:%s]",
                         DOWNLOAD_RESOURCE_TABLE_NAME,
                         DOWNLOAD_RESOURCE_TABLE_COLUMN_DETAIL_ID);
    }

    // テーブルカラム：「削除フラグ」の存在チェック
    if (!isColumnExist(DOWNLOAD_RESOURCE_TABLE_NAME,
                       DOWNLOAD_RESOURCE_TABLE_COLUMN_DELETED)) {
        Bool bolFlg = this->addColumnToTable(
            DOWNLOAD_RESOURCE_TABLE_NAME,
            DOWNLOAD_RESOURCE_TABLE_COLUMN_DELETED, kTSQLiteDataTypeInteger);
        JOKER_ASSERT_MSG(bolFlg, "Column add failed!!![TableName:%s Column:%s]",
                         DOWNLOAD_RESOURCE_TABLE_NAME,
                         DOWNLOAD_RESOURCE_TABLE_COLUMN_DELETED);
    }

    // 既存データレコード数を取得する
    S32 dbRecordCount = this->getRecordCount(DOWNLOAD_RESOURCE_TABLE_NAME);
    S32 recordCount = dbRecordCount + iNewResourcesCount;

    // メモリを初期化にする
    this->initMemorySize(recordCount);

    // ローカルDBから、データをロードする
    if (dbRecordCount > 0) {
        const Bool isLoadSuccessed = this->loadDataFromLocalDB(dbRecordCount);
        JOKER_ASSERT_MSG(isLoadSuccessed, "Download info load failed!!!!");
    }
}

/**
 * @brief 既存のリソースをローカルDBへ全件退避されたかどうかのチェックを行う
 * @return 全件退避フラグ
 */
const Bool DownloadParameter::hadAllResourcesInfoSavedToLocalDB() {
    TResourceInfo* pLoop = NULL;
    S32 countTmp = 0;
    while (countTmp < resources_.count_) {
        pLoop = resources_.data_ + countTmp;
        if (-1 == pLoop->resourceId_) {
            ++countTmp;
            continue;
        }
        if (!pLoop->localDbSaved_) {
            return false;
        }
        ++countTmp;
    }
    return true;
}

/**
 * @brief リソース全件をローカルDBへ退避する
 */
const void DownloadParameter::saveAllResourcesInfoToLocalDB() {
    TResourceInfo* pLoop = NULL;
    S32 countTmp = 0;

    this->isAllResourceSaveThreadStoped_ = false;
    Bool isAllSaveSuccessed = true;
    while (countTmp < resources_.count_) {
        
        // リソース修復などで、中断された場合
        if (this->interruptAllResourceSaveThread_) {
            isAllSaveSuccessed = false;
            break;
        }
        
        pLoop = resources_.data_ + countTmp;

        if (!pLoop) {
            ++countTmp;
            continue;
        }

        if (-1 == pLoop->resourceId_) {
            ++countTmp;
            continue;
        }

        // 退避されなかった場合
        if (!pLoop->localDbSaved_) {
            const S32 maxRetryCount = 3;
            S32 retryCount = 0;
            while (retryCount < maxRetryCount) {
                Bool saveFlg = this->saveResourceInfoToLocalDB(pLoop);
                if (saveFlg) {
                    pLoop->localDbSaved_ = true;
                    break;
                }

                usleep(100);
                ++retryCount;
            }
            if (retryCount >= maxRetryCount) {
                JOKER_ASSERT_MSG(false,
                                 "Resource Save Failed!!![ResourceId:%d]",
                                 pLoop->resourceId_);
                isAllSaveSuccessed = false;
            }
        }
        ++countTmp;
    }
    
    // 全リソースを成功に保存された場合
    if (isAllSaveSuccessed) {
        // リソース情報を一回全件保存したので、ダウンロード情報を再ロードする
        const S32 dbRecordCount =
        this->getRecordCount(DOWNLOAD_RESOURCE_TABLE_NAME);
        
        // メモリを初期化にする
        this->initMemorySize(dbRecordCount);
        
        // ローカルDBから、データをロードする
        if (dbRecordCount > 0) {
            const Bool isLoadSuccessed = this->loadDataFromLocalDB(dbRecordCount);
            JOKER_ASSERT_MSG(isLoadSuccessed, "Download info load failed!!!!");
        }
    }
    this->isAllResourceSaveThreadStoped_ = true;
}

/**
 * @brief 前回のリソース更新日付を設定する
 * @param[in] iLastResourceUpdateDate 前回のリソース更新日付
 */
const void DownloadParameter::SetLastResourceDate(
    const S64 iLastResourceUpdateDate) {
    const S64 lastResourceUpdateDateTmp = this->lastResourceUpdateDate_;
    if (0 < iLastResourceUpdateDate) {
        this->lastResourceUpdateDate_ =
            MAX(this->lastResourceUpdateDate_, iLastResourceUpdateDate);
    }

    JOKER_DEBUG(
        "\n[Debug:C "
        "I/"
        "A]DownloadParameter::SetLastResourceDate:[lastResourceUpdateDate %lld "
        "-> %lld]\n",
        lastResourceUpdateDateTmp, this->lastResourceUpdateDate_);
}

/**
 * @brief 前回のリソース情報を設定する
 * @param[in] iLastResourceId 前回のリソースID
 * @param[in] iLastResourceUpdateDate 前回のリソース更新日付
 */
const void DownloadParameter::SetLastResourceInfo(
    const S32 iLastResourceId, const S64 iLastResourceUpdateDate) {
    const S32 lastResourceIdTmp = this->lastResourceId_;
    if (0 < iLastResourceId) {
        this->lastResourceId_ = MAX(this->lastResourceId_, iLastResourceId);
    }
    const S64 lastResourceUpdateDateTmp = this->lastResourceUpdateDate_;
    if (0 < iLastResourceUpdateDate) {
        this->lastResourceUpdateDate_ =
            MAX(this->lastResourceUpdateDate_, iLastResourceUpdateDate);
    }

    JOKER_DEBUG(
        "\n[Debug:C "
        "I/"
        "A]DownloadParameter::SetLastResourceInfo:[lastResourceId  %d -> "
        "%d][lastResourceUpdateDate %lld -> %lld]\n",
        lastResourceIdTmp, this->lastResourceId_, lastResourceUpdateDateTmp,
        this->lastResourceUpdateDate_);
}

/**
 * @brief 前回のリソース情報を保存する
 */
const void DownloadParameter::saveLastResourceInfo() {
    if (0 < this->lastResourceId_) {
        Chaos::MasterDataManager::MasterOtherData::updateCacheInfoData(
            "lastResourceId", this->lastResourceId_);
    }
    if (0 < this->lastResourceUpdateDate_) {
        Char strBuffer[64];
        memset(strBuffer, 0x00000000, sizeof(strBuffer));
        sprintf(strBuffer, "%lld", this->lastResourceUpdateDate_);
        Chaos::MasterDataManager::MasterOtherData::updateCacheInfoData(
            "lastResourceUpdateDate", strBuffer);
    }

    JOKER_DEBUG(
        "\n[Debug:C "
        "I/"
        "A]DownloadParameter::saveLastResourceInfo:[lastResourceId -> "
        "%d][lastResourceUpdateDate -> %lld]\n",
        this->lastResourceId_, this->lastResourceUpdateDate_);
}

/**
 * @brief ダウンロード完了時で、更新用のメソッド
 * @param[in] iDownloaderNo ダウンローダーNo
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iResourceId リソースID
 * @param[in] iIsBackgroundDownload バックグラウンドDLフラグ
 */
const void DownloadParameter::updateResourceInfoWhenDownloaded(
    const S32 iDownloaderNo, const S32 iDownloadIndex, const S32 iResourceId,
    const Bool iIsBackgroundDownload) {
    if (-1 >= iResourceId) {
        return;
    }

    TResourceInfo* pTargetTmp = this->getResourceInfoWithWritable(iResourceId);

    pthread_mutex_lock(&sleep_info_update_mutex_);

    TDownloadDetailInfo* downloadDetail =
        this->getDownloadDetail(iDownloadIndex);
    JOKER_ASSERT_MSG(downloadDetail,
                     "The download detail is null!!![DownloadIndex:%d]",
                     iDownloadIndex);

    // ダウンロード完了数をカウントする
    ++downloadDetail->downloaded_count;

    // ダウンロード完了フラグを設定する
    if (!pTargetTmp->downloaded_) {
        pTargetTmp->downloaded_ = true;
    }

    pthread_mutex_unlock(&sleep_info_update_mutex_);

#ifdef DEBUG
    {
        const Char* filename_ =
            strrchr(pTargetTmp->downloadUrl_.c_str(), '/') + 1;

        const TDownloadedCountInfo countInfo =
            this->getDownloadedCountInfo(iDownloadIndex);
        JOKER_DEBUG(
            "\n[Debug:C "
            "I/"
            "A][%d/%d]DownloadParameter::updateResourceInfoWhenDownloaded:"
            ":["
            "Successed][ResourceId:%d][%d/%d][Size:%6.1f KB]%s -> "
            "Downloaded[0x%08x]:%s \n",
            iDownloaderNo, iDownloadIndex, pTargetTmp->resourceId_,
            countInfo.downloaded_count, countInfo.targets_count,
            (pTargetTmp->dataSize_ / 1024.0f),
            ((filename_) ? filename_ : "empty"), (unsigned long)pTargetTmp,
            (pTargetTmp->downloaded_) ? "true" : "false");
    }

#endif
}

/**
 * @brief 解凍完了時で、更新用のメソッド
 * @param[in] iDownloadIndex ダウンロードインデックス
 * @param[in] iUnzipIndex 解凍インデックス
 * @param[in] iResourceId リソースID
 * @param[in] iIsBackgroundDownload バックグラウンドDLフラグ
 */
const void DownloadParameter::updateResourceInfoWhenUnziped(
    const S32 iDownloadIndex, const S32 iUnzipIndex, const S32 iResourceId,
    const Bool iIsBackgroundDownload) {
    if (-1 >= iResourceId) {
        return;
    }

    TResourceInfo* pTargetTmp = this->getResourceInfoWithWritable(iResourceId);

    pthread_mutex_lock(&sleep_info_update_mutex_);

    TDownloadDetailInfo* downloadDetail =
        this->getDownloadDetail(iDownloadIndex);
    JOKER_ASSERT_MSG(downloadDetail,
                     "The download detail is null!!![DownloadIndex:%d]",
                     iDownloadIndex);

    // ダウンロード完了数をカウントする
    ++downloadDetail->unziped_count;

    // 解凍完了フラグを設定する
    if (!pTargetTmp->unziped_) {
        pTargetTmp->unziped_ = true;

        if (pTargetTmp) {
            const S32 maxRetryCount = 3;
            S32 retryCount = 0;
            while (retryCount < maxRetryCount) {
                Bool saveFlg = this->saveResourceInfoToLocalDB(pTargetTmp);
                if (saveFlg) {
                    pTargetTmp->localDbSaved_ = true;
                    break;
                }

                usleep(100);
                ++retryCount;
            }
            if (retryCount >= maxRetryCount) {
                JOKER_ASSERT_MSG(false,
                                 "Resource Save Failed!!![ResourceId:%d]",
                                 pTargetTmp->resourceId_);
            }
        }
    }

    pthread_mutex_unlock(&sleep_info_update_mutex_);

#ifdef DEBUG
    {
        const Char* filename_ =
            strrchr(pTargetTmp->downloadUrl_.c_str(), '/') + 1;

        const TDownloadedCountInfo countInfo =
            this->getDownloadedCountInfo(iDownloadIndex);

        JOKER_DEBUG(
            "\n[Debug:C "
            "I/"
            "A][%d/%d]DownloadParameter::updateResourceInfoWhenUnziped::["
            "Successed][ResourceId:%d][%d/%d][Size:%6.1f KB]%s unziped[0x%08x] "
            ": %s\n",
            iDownloadIndex, iUnzipIndex, pTargetTmp->resourceId_,
            countInfo.unziped_count, countInfo.targets_count,
            (pTargetTmp->dataSize_ / 1024.0f),
            ((filename_) ? filename_ : "empty"), (unsigned long)pTargetTmp,
            (pTargetTmp->unziped_) ? "true" : "false");
    }

#endif
}

/**
 * @brief ローカルDBから、データをロードする
 * @param[in] iResourcesCount リソースカウンター
 * @return ロード成功フラグ
 */
const Bool DownloadParameter::loadDataFromLocalDB(const S32 iResourcesCount) {
    const Char* fields = "ResID,ResUrl,SyncFlg,Completed,Type,DetailId";
    const Char* where = "Deleted = 0";

    sqlite3* handle_sqlite = Chaos::MasterDB::sharedDB()->getDownloadDatabase();
    JOKER_ASSERT_MSG(handle_sqlite, "The handle of sqlite is invalid!!!!");

    S32 count = iResourcesCount;
    if (-1 == iResourcesCount) {
        count = this->getRecordCount(DOWNLOAD_RESOURCE_TABLE_NAME);
    }

    // DBからロードする
    sqlite3_stmt* stmt = 0;
    Char strTmp[512];
    if ((stmt = lib::SQLITE3_SelectFrom(handle_sqlite, fields,
                                        DOWNLOAD_RESOURCE_TABLE_NAME, where)) !=
        0) {
        S32 ret;
        S32 j = 0;
        while ((ret = sqlite3_step(stmt)) != SQLITE_DONE) {
            JOKER::TResourceInfo retResInfo;
            if (SQLITE_ROW ==
                ret)  // one row is ready : call getColumn(N) to access it
            {
                S32 i = 0;
                JOKER_ASSERT(count != j);
                retResInfo.resourceId_ = sqlite3_column_int(stmt, i++);

                memset(strTmp, 0x00000000, sizeof(strTmp));
                strncpy(strTmp, (const Char*)sqlite3_column_text(stmt, i++),
                        sizeof(strTmp));
                retResInfo.downloadUrl_ = strTmp;

                retResInfo.syncFlg_ = sqlite3_column_int(stmt, i++);

                Bool completed = sqlite3_column_int(stmt, i++);
                if (completed) {
                    retResInfo.downloaded_ = completed;
                    retResInfo.unziped_ = completed;
                } else {
                    retResInfo.downloaded_ = false;
                    retResInfo.unziped_ = false;
                }
                retResInfo.deleted_ = false;

                const S32 typeTmp = sqlite3_column_int(stmt, i++);
                retResInfo.resourceType_ = TResourceType(typeTmp);

                retResInfo.detailId_ = sqlite3_column_int(stmt, i++);

                ++j;
            } else {
                JOKER_DEBUG("%s\n", sqlite3_errmsg(handle_sqlite));
                lib::SQLITE3_Finalize(stmt);

                destroyMemory();
                return false;
            }

            // 退避フラグ
            retResInfo.localDbSaved_ = true;

            // リソース情報を追加する
            this->addResourceInfo(&retResInfo);
        }

        JOKER_ASSERT(count == j);
        lib::SQLITE3_Finalize(stmt);
        return true;
    }

    JOKER_DEBUG("%s\n", sqlite3_errmsg(handle_sqlite));
    return false;
}

/**
 * @brief テーブルの既存レコードカウンターを取得する
 * @param[in] iTableName テーブル名
 * @return レコードカウンター
 */
S32 DownloadParameter::getRecordCount(const Char* iTableName) {
    sqlite3* handle_sqlite = Chaos::MasterDB::sharedDB()->getDownloadDatabase();
    JOKER_ASSERT_MSG(handle_sqlite, "The handle of sqlite is invalid!!!!");

    S32 count = lib::SQLITE3_GetRowCount(handle_sqlite, iTableName, NULL,
                                         "Deleted = 0");
    JOKER_ASSERT_MSG((count > -1), "Table info get error : %s", iTableName);
    if (count <= 0) {
        return 0;
    }
    return count;
}

/**
 * @brief カラムの存在チェックを行う
 * @param[in] iTableName テーブル名
 * @param[in] iColumnName カラム名
 * @return カラム存在フラグ
 */
Bool DownloadParameter::isColumnExist(const Char* iTableName,
                                      const Char* iColumnName) {
    sqlite3* handle_sqlite = Chaos::MasterDB::sharedDB()->getDownloadDatabase();
    JOKER_ASSERT_MSG(handle_sqlite, "The handle of sqlite is invalid!!!!");

    S32 count =
        lib::SQLITE3_GetRowCount(handle_sqlite, iTableName, iColumnName);
    if (count == -1) {
        return false;
    }
    return true;
}

/**
 * @brief カラムをテーブルへ追加する
 * @param[in] iTableName テーブル名
 * @param[in] iColumnName カラム名
 * @param[in] iDataType データタイプ
 * @return カラム追加成功フラグ
 */
Bool DownloadParameter::addColumnToTable(const Char* iTableName,
                                         const Char* iColumnName,
                                         const TSQLiteDataType iDataType) {
    sqlite3* handle_sqlite = Chaos::MasterDB::sharedDB()->getDownloadDatabase();
    JOKER_ASSERT_MSG(handle_sqlite, "The handle of sqlite is invalid!!!!");

    Bool isSuccessed = true;
    Char sqlBuffer[512];
    memset(sqlBuffer, 0x00000000, sizeof(sqlBuffer));
    switch (iDataType) {
        case kTSQLiteDataTypeInteger: {
            sprintf(sqlBuffer, "ALTER TABLE %s ADD %s INTEGER", iTableName,
                    iColumnName);
        } break;

        case kTSQLiteDataTypeText: {
            sprintf(sqlBuffer, "ALTER TABLE %s ADD %s TEXT", iTableName,
                    iColumnName);
        } break;

        default:
            isSuccessed = false;
            break;
    }

    // 更新トランザクションを開始
    isSuccessed = lib::SQLITE3_TransactionBegin(handle_sqlite);
    if (!isSuccessed) {
        JOKER_DEBUG(
            "\n[Debug:C "
            "I/A]DownloadParameter::addColumnToTable::SQLITE3_TransactionBegin "
            "Failed!!!!\n");
        return isSuccessed;
    }

    if (std::strlen(sqlBuffer) > 0) {
        isSuccessed = lib::SQLITE3_SqlExec(handle_sqlite, sqlBuffer);
        if (isSuccessed) {
            // コミットする
            isSuccessed = lib::SQLITE3_TransactionCommit(handle_sqlite, false);
        } else {
            // 失敗の場合、ロールバック
            lib::SQLITE3_TransactionRollback(handle_sqlite);
        }
    }
    if (!isSuccessed) {
        JOKER_DEBUG(
            "\n[Debug:C I/A][Warning]DownloadParameter::addColumnToTable "
            "Column type is invalid!!![TableName:%s Column:%s "
            "DataType:%d]\n[SQL:%s]\n",
            iTableName, iColumnName, iDataType, sqlBuffer);
    }
    return isSuccessed;
}

/**
 * @brief リソース情報をローカルDBへ退避する
 * @param[in] iResourceInfo リソース情報
 * @return 退避成功フラグ
 */
Bool DownloadParameter::saveResourceInfoToLocalDB(
    const TResourceInfo* iResourceInfo) {
    sqlite3* handle_sqlite = Chaos::MasterDB::sharedDB()->getDownloadDatabase();
    JOKER_ASSERT_MSG(handle_sqlite, "The handle of sqlite is invalid!!!!");

    
    // todo need mutex
    Char where[512];
    memset(where, 0x00000000, sizeof(where));
    sprintf(where, "ResID = %d", iResourceInfo->resourceId_);

    const S32 count = lib::SQLITE3_GetRowCount(
        handle_sqlite, DOWNLOAD_RESOURCE_TABLE_NAME, NULL, where);
    Bool isSuccessed = true;
    Char sqlQuery[512];
    memset(sqlQuery, 0x00000000, sizeof(sqlQuery));

    // 解凍フラグの設定
    Bool unzipedTmp = iResourceInfo->unziped_;
    if (iResourceInfo->syncFlg_) {
        unzipedTmp = iResourceInfo->syncFlg_;
    }

    if (count > 0) {
        // 更新
        sprintf(sqlQuery,
                "UPDATE %s SET ResUrl = '%s', SyncFlg = %d, Completed "
                "= %d, Type = %d, DetailId = %lld, Deleted = %d WHERE %s ",
                DOWNLOAD_RESOURCE_TABLE_NAME,
                iResourceInfo->downloadUrl_.c_str(), iResourceInfo->syncFlg_,
                unzipedTmp, (S32)iResourceInfo->resourceType_,
                iResourceInfo->detailId_, iResourceInfo->deleted_, where);
    } else {
        // 挿入
        sprintf(sqlQuery,
                "INSERT INTO %s ( ResID, ResUrl, SyncFlg, Completed, Type, "
                "DetailId, Deleted ) VALUES ( %d, '%s', %d, %d, %d, %lld, %d )",
                DOWNLOAD_RESOURCE_TABLE_NAME, iResourceInfo->resourceId_,
                iResourceInfo->downloadUrl_.c_str(), iResourceInfo->syncFlg_,
                unzipedTmp, (S32)iResourceInfo->resourceType_,
                iResourceInfo->detailId_, iResourceInfo->deleted_);
    }

    // 更新トランザクションを開始
    isSuccessed = lib::SQLITE3_TransactionBegin(handle_sqlite);
    if (!isSuccessed) {
        JOKER_DEBUG(
            "\n[Debug:C "
            "I/"
            "A]DownloadParameter::saveResourceInfoToLocalDB::SQLITE3_"
            "TransactionBegin Failed!!!!\n");
        return isSuccessed;
    }

    JOKER_DEBUG(
        "\n[Debug:C "
        "I/A]DownloadParameter::saveResourceInfoToLocalDB\n[SQL:%s]\n",
        sqlQuery);
    if (std::strlen(sqlQuery) > 0) {
        isSuccessed = lib::SQLITE3_SqlExec(handle_sqlite, sqlQuery);
        if (isSuccessed) {
            // コミットする
            isSuccessed = lib::SQLITE3_TransactionCommit(handle_sqlite);
        } else {
            // 失敗の場合、ロールバック
            lib::SQLITE3_TransactionRollback(handle_sqlite);
        }
    }
    if (!isSuccessed) {
        JOKER_DEBUG(
            "\n[Debug:C "
            "I/A][Warning]DownloadParameter::saveResourceInfoToLocalDB Save "
            "Failed!!!\n[SQL:%s]\n",
            sqlQuery);
    } else {
        //        // ダウンロード＆解凍完了の場合、ラスト情報を設定する
        //        if (iResourceInfo->downloaded_ && iResourceInfo->unziped_) {
        //            S32 resourceId = iResourceInfo->resourceId_;
        //            S64 updateDate = iResourceInfo->updateDate_;
        //            this->SetLastResourceInfo(resourceId, updateDate);
        //        }
    }
    return isSuccessed;
}

const Bool DownloadParameter::hadAllResourcesInfoUnzipedToLocalDB() {
    TResourceInfo* pLoop = NULL;
    S32 countTmp = 0;
    while (countTmp < resources_.count_) {
        pLoop = resources_.data_ + countTmp;
        if (-1 == pLoop->resourceId_) {
            ++countTmp;
            continue;
        }
        if (!pLoop->unziped_) {
            return false;
        }
        ++countTmp;
    }
    return true;
}

/**
 * @brief
 * ローカルDBへ、すでにダウンロードされたリソースカード情報をリセットする(デバッグ機能のみ、使う)
 * @param[in] iResourceType リソースタイプ
 * @param[in] iDetailId 詳細ID
 */
const Bool DownloadParameter::resetRuntimeDownloadResourceInfoToLocalDB(
    const TResourceType iResourceType, const S32 iDetailId) {
    sqlite3* handle_sqlite = Chaos::MasterDB::sharedDB()->getDownloadDatabase();
    JOKER_ASSERT_MSG(handle_sqlite, "The handle of sqlite is invalid!!!!");

    Char where[512];
    memset(where, 0x00000000, sizeof(where));
    sprintf(where, "Type = %d", (TResourceType)iResourceType);
    if (-1 != iDetailId) {
        sprintf(where, "%s AND DetailId = %d", where, iDetailId);
    }

    const S32 count = lib::SQLITE3_GetRowCount(
        handle_sqlite, DOWNLOAD_RESOURCE_TABLE_NAME, NULL, where);
    Bool isSuccessed = true;
    Char sqlQuery[512];
    memset(sqlQuery, 0x00000000, sizeof(sqlQuery));

    if (count > 0) {
        // 更新
        sprintf(sqlQuery,
                "UPDATE %s SET Completed = 0 "
                "WHERE %s ",
                DOWNLOAD_RESOURCE_TABLE_NAME, where);

        // 更新トランザクションを開始
        isSuccessed = lib::SQLITE3_TransactionBegin(handle_sqlite);
        if (!isSuccessed) {
            JOKER_DEBUG(
                "\n[Debug:C "
                "I/"
                "A]DownloadParameter::saveResourceInfoToLocalDB::SQLITE3_"
                "TransactionBegin Failed!!!!\n");
            return isSuccessed;
        }

        if (std::strlen(sqlQuery) > 0) {
            isSuccessed = lib::SQLITE3_SqlExec(handle_sqlite, sqlQuery);
            if (isSuccessed) {
                // コミットする
                isSuccessed = lib::SQLITE3_TransactionCommit(handle_sqlite);
            } else {
                // 失敗の場合、ロールバック
                lib::SQLITE3_TransactionRollback(handle_sqlite);
            }
        }
        if (!isSuccessed) {
            JOKER_DEBUG(
                "\n[Debug:C "
                "I/A][Warning]DownloadParameter::saveResourceInfoToLocalDB "
                "Save "
                "Failed!!!\n[SQL:%s]\n",
                sqlQuery);
        }
    }
    return isSuccessed;
}

/**
 * @brief
 * パラメーターへ、すでにダウンロードされたリソースカード情報をリセットする(デバッグ機能のみ、使う)
 * @param[in] iResourceType リソースタイプ
 * @param[in] iDetailId 詳細ID
 */
const Bool DownloadParameter::resetRuntimeDownloadResourceInfoToParameter(
    const TResourceType iResourceType, const S32 iDetailId) {
    TResourceInfo* pLoop = resources_.data_;
    S32 countTmp = 0;
    while (pLoop) {
        // メモリ上で超える場合
        if (countTmp >= resources_.count_) {
            break;
        }

        if (iResourceType != pLoop->resourceType_) {
            ++countTmp;
            ++pLoop;
            continue;
        }

        if (-1 >= iDetailId) {
            pLoop->downloaded_ = false;
            pLoop->unziped_ = false;
        } else {
            if (iDetailId == pLoop->detailId_) {
                pLoop->downloaded_ = false;
                pLoop->unziped_ = false;
            }
        }

        ++countTmp;
        ++pLoop;
    }
    return NULL;

    return true;
}

const Bool DownloadParameter::checkHealthWithDownloadResources() const {
    if(strncmp(APP_VERSION_NAME, "3.12.0", 16) != 0) {
        // 3.12.0のみ問題があるので、それ以外のバージョン(3.11.0)はOKとみなす
        return true;
    }
    
    const Char* fields = "ResID";

    sqlite3* handle_sqlite = Chaos::MasterDB::sharedDB()->getDownloadDatabase();
    JOKER_ASSERT_MSG(handle_sqlite, "The handle of sqlite is invalid!!!!");

    sqlite3_stmt* stmt = 0;
    if ((stmt = lib::SQLITE3_SelectFrom(
             handle_sqlite, fields, DOWNLOAD_RESOURCE_TABLE_NAME, NULL)) != 0) {
        S32 ret;
        S32 j = 0;
        while ((ret = sqlite3_step(stmt)) != SQLITE_DONE) {
            if (SQLITE_ROW == ret) {
                S32 i = 0;
                S32 id = sqlite3_column_int(stmt, i++);
                if (id != j + 1) {
                    // * インデックスとIDが不一致（抜けがある） *
                    return false;
                }
                ++j;
            } else {
                JOKER_DEBUG("%s\n", sqlite3_errmsg(handle_sqlite));
                lib::SQLITE3_Finalize(stmt);
                return false;
            }
        }

        lib::SQLITE3_Finalize(stmt);
    }

    JOKER_DEBUG("%s\n", sqlite3_errmsg(handle_sqlite));
    return true;
}

JOKER_END_NAMESPACE