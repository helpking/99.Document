//
//  download_parameter.h
//  chaos
//
//  ダウンロード用のパラメーター
//
//  Created by 何 利強 on 2016/09/06.
//
//

#ifndef download_parameter_h
#define download_parameter_h

#include "parameter/download_parameter_types.h"

#ifdef DEBUG
#define RUNTIME_DOWNLOAD_DEBUG
#endif

USING_NS_CC;
USING_NS_CC_EXT;

JOKER_BEGIN_NAMESPACE

/**
 * @brief SQLiteデータータイプ
 */
typedef enum TSQLiteDataType {
    kTSQLiteDataTypeInvalid = -1,
    kTSQLiteDataTypeInteger,
    kTSQLiteDataTypeText,
    kTSQLiteDataTypeMax
} TSQLiteDataType;

/**
 * @brief ダウンロード用のパラメーター
 */
class DownloadParameter {
public:
    DownloadParameter();
    ~DownloadParameter();

    /**
     * @brief 読み込む用のリソース情報を取得する
     * @param[in] iResourceId リソースID
     * @return リソース情報
     */
    const TResourceInfo* getResourceInfoWithReadOnly(
        const S32 iResourceId) const;

    /**
     * @brief 読み込む用のリソース情報を取得する
     * @param[in] iResourceType リソースタイプ
     * @param[in] iDetailId 詳細ID
     * @return リソース情報
     */
    const TResourceInfo* getResourceInfoWithReadOnly(
        const TResourceType iResourceType, const S64 iDetailId) const;

    /**
     * @brief 書き込む用のリソース情報を取得する
     * @param[in] iResourceId リソースID
     * @return リソース情報
     */
    TResourceInfo* getResourceInfoWithWritable(const S32 iResourceId);

    /**
     * @brief リソース情報を追加する
     * @param[in] iResourceInfo リソース情報
     */
    const void addResourceInfo(const TResourceInfo* iResourceInfo);

    /**
     * @brief ダウンロード用のターゲット情報を追加する
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iResourceId リソースID
     */
    void pushDownloadTargetInfo(const S32 iDownloadIndex,
                                const S32 iResourceId);

    /**
     * @brief ダウンロード用の情報を追加する
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iResourceType リソースタイプ
     * @param[in] iDetailId 詳細ID
     */
    void pushDownloadTargetInfoByDetailId(
        const S32 iDownloadIndex, const JOKER::TResourceType iResourceType,
        const S64 iDetailId);

    /**
     * @brief チェック用の情報をチェックする（ファイル名）
     * @param[in] iCheckFileName チェックファイル名
     */
    void addCheckDetailInfo(const Char* iCheckFileName);

    /**
     * @brief チェック用の情報をチェックする
     * @param[in] iCheckType チェックタイプ
     * @param[in] iCheckDetailId チェック用の詳細ID
     */
    void addCheckDetailInfo(const TResourceType iCheckType,
                            const S32 iCheckDetailId);

    /**
     * @brief ファイルの存在チェック
     * @param[in] iFileName ファイル名
     */
    const Bool isFileExist(const char* iFileName);

    /**
     * @brief 全ターゲットズがダウンロードされたかどうかのチェックを行う
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iIsBackgroundDownloadFlg バックグラウンドDLフラグ
     * @return 全ダウンロードフラグ
     */
    Bool isAllTargetsDownloaded(const S32 iDownloadIndex,
                                const Bool iIsBackgroundDownloadFlg);

    /**
     * @brief 全ターゲットズが解凍されたかどうかのチェックを行う
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iIsBackgroundDownloadFlg バックグラウンドDLフラグ
     * @return 全解凍フラグ
     */
    Bool isAllTargetsUnziped(const S32 iDownloadIndex,
                             const Bool iIsBackgroundDownloadFlg);

    /**
     * @brief 都合DL：一括ダウンロード用のターゲットズ一覧を作成する
     * @param[in] iDownloadIndex ダウンロードインデックス
     */
    const void createRuntimeDownloadTargetsForAll(const S32 iDownloadIndex);

    /**
     * @brief カードのダウンロードチェックを行う
     * @param[in] iResourceType リソースタイプ
     * @param[in] iDetailId 詳細ID
     * @return リソースのダウンロードフラグ
     */
    const Bool isResourceDownloadedByDetailId(const TResourceType iResourceType,
                                              const S32 iDetailId) const;

    /**
     * @brief ダウンロードターゲットの存在チェックを行う
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iIsBackgroundDownloadFlg バックグラウンドDLフラグ
     * @return ダウンロードターゲットズの存在フラグ
     */
    const Bool isDownloadTargetsExist(const S32 iDownloadIndex,
                                      const Bool iIsBackgroundDownloadFlg);

    /**
     * @brief チェック詳細情報(ファイルパスで)の存在チェックを行う
     * @return チェック詳細情報(ファイルパスで)の存在フラグ
     */
    const Bool isCheckDetailInfoExistByFilePath() const;

    /**
     * @brief 前回のリソース更新日付を設定する
     * @param[in] iLastResourceUpdateDate 前回のリソース更新日付
     */
    const void SetLastResourceDate(const S64 iLastResourceUpdateDate);
    
    /**
     * @brief 前回のリソース情報を設定する
     * @param[in] iLastResourceId 前回のリソースID
     * @param[in] iLastResourceUpdateDate 前回のリソース更新日付
     */
    const void SetLastResourceInfo(const S32 iLastResourceId,
                                   const S64 iLastResourceUpdateDate);

    /**
     * @brief 前回のリソース情報を保存する
     */
    const void saveLastResourceInfo();

    /**
     * @brief ダウンロード詳細情報を取得する
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @return ダウンロード詳細情報
     */
    TDownloadDetailInfo* getDownloadDetail(const S32 iDownloadIndex);

    /**
     * @brief 指定されたカレントダウンロードインデックスで、
     *        前回残ったダウンロードターゲットズ情報ををクリアする
     * @param[in] iCurrentDownloadIndex カレントダウンロードインデックス
     */
    const void clearDownloadDetailsByCurrentDownloadIndex(
        const S32 iCurrentDownloadIndex);

    /**
     * @brief ダウンロードターゲットズカウントを取得する
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @return ダウンロードターゲットズカウント
     */
    S32 getDownloadTargetsCount(const S32 iDownloadIndex);

    /**
     * @brief チェック詳細情報の存在チェックを行う
     * @return チェック詳細情報の存在フラグ
     */
    inline const Bool isCheckDetailInfoExist() const {
        return (this->check_details_.size() > 0);
    };

    /**
     * @brief ダウンロード用のチェック詳細情報をクリアする
     */
    inline const void clearDownloadCheckDetails() {
        this->check_details_.clear();
    };

    /**
     * @brief ダウンロード用のチェック詳細情報を取得する
     * @return ダウンロード用のチェック詳細情報
     */
    inline TDownloadCheckDetailsInfo getDownloadCheckDetails() {
        return this->check_details_;
    };

    /**
     * @brief サーバーに問い合わせる時、チェック詳細情報の追加をロックします
     */
    inline const void lockAddCheckDetail() { this->addCheckLockFlg_ = true; }

    /**
     * @brief
     * サーバーに問い合わせる以外の時、チェック詳細情報の追加をアンロックします
     */
    inline const void unlockAddCheckDetail() { this->addCheckLockFlg_ = false; }

    /**
     * @brief チェック用の詳細情報で、問い合わせてるところで、
     *        追加ロックをかけてるかどうかのチェックを行う
     * @return 追加ロックフラグ
     */
    inline const Bool isAddCheckLocked() const {
        return this->addCheckLockFlg_;
    };

    /**
     * @brief ダウンロードターゲットズ一覧を取得する
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @return ダウンロードターゲットズ一覧
     */
    inline const JOKER::TDownloadDetailInfo* getDownloadTargets(
        const S32 iDownloadIndex) {
        if (-1 >= iDownloadIndex) {
            return NULL;
        }
        return this->getDownloadDetail(iDownloadIndex);
    };

    /**
     * @brief 全ターゲットズのダウンロードが完了するかどうかのチェックを行う
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iIsBackgroundDownloadFlg バックグラウンドDLフラグ
     * @return 完了フラグ
     */
    inline const Bool isAllTargetsCompleted(
        const S32 iDownloadIndex, const Bool iIsBackgroundDownloadFlg) {
        return (this->isAllTargetsDownloaded(iDownloadIndex,
                                             iIsBackgroundDownloadFlg) &&
                this->isAllTargetsUnziped(iDownloadIndex,
                                          iIsBackgroundDownloadFlg));
    };
    
    /**
     * @brief DLResourcesInfoテーブルに入っているはずのレコード数を保持する
     * deviceinfo/registerから取得
     * DL後、マイページ遷移前に検証
     */
    ADK_INLINE const void setDLResourcesInfoRecordCount(S32 count);

    /**
     * @brief DLResourcesInfoテーブルに入っているはずのレコード数を取得する
     * deviceinfo/registerから取得
     * DL後、マイページ遷移前に検証
     */
    ADK_INLINE const S32 getDLResourcesInfoRecordCount();
    
    /**
     * @brief DLResourcesInfoテーブルへの事前登録を中断する
     */
    ADK_INLINE const void interruptAllResourcesSaveThreadToLocalDB();
    /**
     * @brief DLResourcesInfoテーブルへの事前登録のスレッドが停止するかどうかの判定
     */
    ADK_INLINE const Bool isAllResourcesSaveThreadStoped();

protected:
private:
    /** @brief 前回リソースID */
    S32 lastResourceId_;
    /** @brief 前回リソース更新日付（単位：ミリ秒） */
    S64 lastResourceUpdateDate_;
    /** @brief リソースズ一覧 */
    TResourcesListInfo resources_;

    /** @brief ダウンロード情報一覧 */
    TDownloadInfos download_infos_;
    /** @brief ダウンロード用のチェック詳細 */
    TDownloadCheckDetailsInfo check_details_;
    /** @brief チェック追加ロックフラグ */
    Bool addCheckLockFlg_;
    /** @brief DLResourcesInfoに設定されているはずの全レコード数(サーバから数値を貰い、各回検証) */
    S32 dlResourceInfoCount_;
    
    /** @brief 全リソース事前保存スレッド中断フラグ */
    Bool interruptAllResourceSaveThread_;
    /** @brief 全リソース事前保存スレッド停止フラグ */
    Bool isAllResourceSaveThreadStoped_;

    /**
     * @brief 書き込む用のリソース情報を取得する
     * @param[in] iResourceType リソースタイプ
     * @param[in] iDetailId 詳細ID
     * @return リソース情報
     */
    TResourceInfo* getResourceInfoWithWritable(
        const JOKER::TResourceType iResourceType, const S64 iDetailId);

    /**
     * @brief リソース情報退避用のメモリを初期化にする
     * @param[in] iResourcesCount リソースカウンター
     */
    void initMemorySize(const S32 iResourcesCount);

    /**
     * @brief ダウンロード用のターゲットズ情報を初期化にする
     * @param[in] iDownloadIndex ダウンロードインデックス
     */
    void initDownloadTargetsInfo(const S32 iDownloadIndex);

    /**
     * @brief リソース情報退避用のメモリをを解放する
     */
    void destroyMemory();

    /**
     * @brief ダウンロード用の情報を追加する
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iResourceInfo リソース情報
     */
    void pushDownloadTargetInfo(const S32 iDownloadIndex,
                                TResourceInfo* iResourceInfo);

    /**
     * @brief ダウンロードターゲット情報が追加されたかどうかの判定
     * @param[in] iDownloadDetail ダウンロード詳細
     * @param[in] iResourceId リソースID
     * @return 追加されたフラグ
     */
    const Bool isDownloadTargetInfoAdded(TDownloadDetailInfo* iDownloadDetail,
                                         const S32 iResourceId);

    /**
     * @brief
     * 指定されたダウンロードインデックスで、ダウンロード詳細情報を削除する
     * @param[in] iDownloadIndex ダウンロードインデックス
     */
    const void removeDownloadDetailByIndex(const S32 iDownloadIndex);

#pragma mark -
#pragma mark Thread Safe

public:
    /**
     * @brief ダウンロードカウント情報を取得する
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @return ダウンロードカウント情報
     */
    TDownloadedCountInfo getDownloadedCountInfo(const S32 iDownloadIndex);

    /**
     * @brief 解凍のターゲット情報を取得する
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iUnzipIndex 解凍のインデックス
     * @param[in] iIsBackgroundDownload バックグラウンドダウンロードフラグ
     */
    TResourceInfo* getUnzipTargetInfo(const S32 iDownloadIndex,
                                      const S32 iUnzipIndex,
                                      const Bool iIsBackgroundDownload);

private:
    /** @brief スレッドセーフ用のミューテックス */
    pthread_mutex_t sleep_info_update_mutex_;

#pragma mark -
#pragma mark SqlLite

public:
    /**
     * @brief ダウンロード情報を初期化にする
     * @param[in] iNewResourceCount
     * ダウンロードレスポンスから、返した新リソースカウンター
     */
    const void initDownloadInfo(const S32 iNewResourcesCount);

    /**
     * @brief 既存のリソースをローカルDBへ全件退避されたかどうかのチェックを行う
     * @return 全件退避フラグ
     */
    const Bool hadAllResourcesInfoSavedToLocalDB();

    /**
     * @brief リソース全件をローカルDBへ退避する
     */
    const void saveAllResourcesInfoToLocalDB();

    /**
     * @brief ダウンロード完了時で、更新用のメソッド
     * @param[in] iDownloaderNo ダウンローダーNo
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iResourceId リソースID
     * @param[in] iIsBackgroundDownload バックグラウンドDLフラグ
     */
    const void updateResourceInfoWhenDownloaded(
        const S32 iDownloaderNo, const S32 iDownloadIndex,
        const S32 iResourceId, const Bool iIsBackgroundDownload = false);

    /**
     * @brief 解凍完了時で、更新用のメソッド
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iUnzipIndex 解凍インデックス
     * @param[in] iResourceId リソースID
     * @param[in] iIsBackgroundDownload バックグラウンドDLフラグ
     */
    const void updateResourceInfoWhenUnziped(
        const S32 iDownloadIndex, const S32 iUnzipIndex, const S32 iResourceId,
        const Bool iIsBackgroundDownload = false);
    /**
     * @brief 既存のリソースをローカルDBへ全件解凍されたかどうかのチェックを行う
     * @return 全件解凍フラグ
     */
    const Bool hadAllResourcesInfoUnzipedToLocalDB();

    /**
     * @brief
     * ローカルDBへ、すでにダウンロードされたリソースカード情報をリセットする(デバッグ機能のみ、使う)
     * @param[in] iResourceType リソースタイプ
     * @param[in] iDetailId 詳細ID
     */
    const Bool resetRuntimeDownloadResourceInfoToLocalDB(
        const TResourceType iResourceType, const S32 iDetailId = -1);

    /**
     * @brief
     * パラメーターへ、すでにダウンロードされたリソースカード情報をリセットする(デバッグ機能のみ、使う)
     * @param[in] iResourceType リソースタイプ
     * @param[in] iDetailId 詳細ID
     */
    const Bool resetRuntimeDownloadResourceInfoToParameter(
        const TResourceType iResourceType, const S32 iDetailId = -1);

    /**
     * @brief downloadResources.dbのリソースIDに抜けがないかをチェックする
     * v3.12における実装時のバグが発生していないかを確認する暫定対応
     * @return 正しく情報が保存されているか
     */
    const Bool checkHealthWithDownloadResources() const;
    
    /**
     * @brief リソース情報をローカルDBへ退避する
     * @param[in] iResourceInfo リソース情報
     * @return 退避成功フラグ
     */
    Bool saveResourceInfoToLocalDB(const TResourceInfo* iResourceInfo);

    
private:
    /**
     * @brief ローカルDBから、データをロードする
     * @param[in] iResourcesCount リソースカウンター
     * @return ロード成功フラグ
     */
    const Bool loadDataFromLocalDB(const S32 iResourcesCount = -1);

    /**
     * @brief テーブルの既存レコードカウンターを取得する
     * @param[in] iTableName テーブル名
     * @return レコードカウンター
     */
    S32 getRecordCount(const Char* iTableName);

    /**
     * @brief カラムの存在チェックを行う
     * @param[in] iTableName テーブル名
     * @param[in] iColumnName カラム名
     * @return カラム存在フラグ
     */
    Bool isColumnExist(const Char* iTableName, const Char* iColumnName);

    /**
     * @brief カラムをテーブルへ追加する
     * @param[in] iTableName テーブル名
     * @param[in] iColumnName カラム名
     * @param[in] iDataType データタイプ
     * @return カラム追加成功フラグ
     */
    Bool addColumnToTable(const Char* iTableName, const Char* iColumnName,
                          const TSQLiteDataType iDataType);
};

ADK_INLINE const void DownloadParameter::setDLResourcesInfoRecordCount(S32 count) {
    dlResourceInfoCount_ = count;
};
ADK_INLINE const S32 DownloadParameter::getDLResourcesInfoRecordCount() {
    return dlResourceInfoCount_;
};
ADK_INLINE const void DownloadParameter::interruptAllResourcesSaveThreadToLocalDB(){
    this->interruptAllResourceSaveThread_ = true;
};
ADK_INLINE const Bool DownloadParameter::isAllResourcesSaveThreadStoped(){
    return this->isAllResourceSaveThreadStoped_;
};

JOKER_END_NAMESPACE

#endif /* download_parameter_h */
