//
//  unziper.h
//  chaos
//
//  解凍用のクラス
//
//  Created by 何 利強 on 2016/09/06.
//
//

#ifndef unziper_h
#define unziper_h

#include "cocos-ext.h"
#include "cocos2d.h"

#include "parameter/download_parameter.h"

USING_NS_CC;
USING_NS_CC_EXT;

namespace Chaos {
namespace ResourcesManager {
class Unziper {
public:
    /**
     * @brief 解凍ステート
     */
    typedef enum TUnzipState {
        kTUnzipStateInvalid = -1,
        /** @brief アイドル */
        kTUnzipStateIdle,
        /** @brief 解凍中 */
        kTUnzipStateUnziping,
        /** @brief 一時停止 */
        kTUnzipStatePausing,
        /** @brief 待機 */
        kTUnzipStateWaiting = kTUnzipStatePausing,
        /** @brief 完了 */
        kTUnzipStateCompleted,
        kTUnzipStateMax
    } TUnzipState;

    /**
     * @brief 解凍者を作成する
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iIsBackgroundDownload バックグラウンドDLフラグ
     */
    static Unziper* create(const S32 iDownloadIndex,
                           const Bool iIsBackgroundDownload = false);
    ~Unziper();

    /**
     * @brief 解凍を開始する
     */
    const void StartUnzip();

    /**
     * @brief 停止してるかどうかのチェック
     * @return 停止フラグ
     */
    Bool isStoped();

    /**
     * @brief 解凍を一時停止にする
     */
    const void Pause();

    /**
     * @brief 解凍を続く
     */
    const void Continue();

    /**
     * @brief 解凍をリセットする
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iIsBackgroundDownload バックグラウンドDLフラグ
     */
    const void Reset(const S32 iDownloadIndex,
                     const Bool iIsBackgroundDownload = false);

    /**
     * @brief 解凍をキャンセルする
     */
    const void Cancel();

    /**
     * @brief 一時停止をチェックする
     * @return 一時停止フラグ
     */
    inline const Bool isPausing() const {
        return (kTUnzipStatePausing == this->state_);
    }

    /**
     * @brief キャンセルされたかどうかのチェック
     * @return キャンセルフラグ
     */
    inline const Bool isCanceled() const { return this->isCanceled_; };

    /**
     * @brief バックグラウンドDLのフラグを設定する
     * @param[in] iDownloadIndex ダウンロードインデックス
     * @param[in] iIsBackgroundDownload バックグラウンドDLのフラグ
     */
    inline const void SetDownloadInfo(const S32 iDownloadIndex,
                                      const Bool iIsBackgroundDownload) {
        this->download_index_ = iDownloadIndex;
        this->isBackgroundDownload_ = iIsBackgroundDownload;
    };

    /**
     * @brief ダウンロードインデックスを取得する
     * @return ダウンロードインデックス
     */
    inline const S32 getDownloadIndex() const { return this->download_index_; }

protected:
    Unziper();

private:
    /** @brief ダウンロードパラメーター */
    JOKER::DownloadParameter* download_parameter_;
    /** @brief ステート */
    TUnzipState state_;

    /** @brief ダウンロードインデックス */
    S32 download_index_;
    /** @brief 解凍インデックス */
    S32 unzip_index_;

    /** @brief バックグラウンドDLフラグ */
    Bool isBackgroundDownload_;

    /** @brief スレッド用の変数 */
    pthread_t thread_;
    pthread_cond_t sleep_condition_;
    pthread_mutex_t sleep_mutex_;

    /** @brief キャンセルフラグ */
    Bool isCanceled_;

    /**
     * \brief ファイルを解凍する
     * \param[in] iUnziper 解凍者
     */
    static void* Unzip(void* iUnziper);
};
}
}

#endif /* unziper_h */
